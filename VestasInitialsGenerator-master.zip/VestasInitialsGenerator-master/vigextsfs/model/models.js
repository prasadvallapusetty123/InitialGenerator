sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device ) {
	"use strict";

	return {
		
		initApplicationConfiguration: function( comp )
		{
			//return new JSONModel("application-config.json").getData();
			/*$.getJSON( "application-config.json", function( data )
			{
				 comp.appconfig = data;
			});*/
			$.ajax
           (
	           	{
	           		url:   "application-config.json",
	           		async: false,
	           		datatype: "json",
	           		success: function(data)
	           		{
	           			comp.appconfig = data;
	           			comp.setModel(new JSONModel(data),"AppConfig" );
	           		},
	           		error: function(err){ throw "Application Config could not be loaded";}
	           	}
           	);
		},
		
		initTestGWData: function()
		{
			var dataF4 = new JSONModel( "test/testData.json" );
			return dataF4;
		},
		
		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},

		createFLPModel: function() {
			var fnGetuser = jQuery.sap.getObject("sap.ushell.Container.getUser"),
				bIsShareInJamActive = fnGetuser ? fnGetuser().isJamActive() : false,
				oModel = new JSONModel({
					isShareInJamActive: bIsShareInJamActive
				});
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		
		createModel: function( data )
		{
			var oModel = new JSONModel(data);
			return oModel;
		}
	};

});