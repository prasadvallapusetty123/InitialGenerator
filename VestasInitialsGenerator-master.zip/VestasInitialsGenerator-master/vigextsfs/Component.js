sap.ui.define([
   "sap/ui/core/UIComponent",
   "sap/ui/model/json/JSONModel",
   "com/vestas/vig/sfsext/model/models",
   "com/vestas/vig/sfsext/classes/Requester",
   "com/vestas/vig/sfsext/classes/OdataLogic",
   "com/gavdi/library/tools/GeneralTools",
   "com/gavdi/library/tools/OdataService"
], function (UIComponent, JSONModel, models, Requester, OdataLogic, GeneralTools, OdataService ) {
   "use strict";
   return UIComponent.extend("com.vestas.vig.sfsext.Component", {
      metadata : {
            manifest: "json"
      },
      init : function () {
         // call the init function of the parent
         UIComponent.prototype.init.apply(this, arguments);
		 this.getRouter().initialize();
		 
		 //Tools we need
		 this._tools = new GeneralTools( this );
		 
		 //System models
		 // set the device model
		this.setModel(models.createDeviceModel(), "device");
		// set the FLP model
		this.setModel(models.createFLPModel(), "FLP");
     
    	 //Load application config
    	 this.initApplicationConfiguration();
    	 
    	 //Setup form model
    	 this.initAndResetForm();
    	 
    	 //Setup UI control model
    	 this.resetUIControlModel();
    	 
    	 //Init the odata service
    	 /*this._odataLogic = new OdataLogic( this );
    	 this._odataService = new OdataService( this, this._odataLogic );
    	 */
    	 
    	 //init the requester
    	 this._requester = new Requester( this );
      },
      resetUIControlModel: function()
      {
      	var data = 
    	 {
    	 	visibleTable:					false,
    	 	visibleInitialsButton:			true,
    	 	visibleInitialsCancelButton:	false
    	 };
    	 this.setModel(new JSONModel(data),"UIControl");
      },
      setTableVisible: function( visible )
      {
      		this.getModel("UIControl").setProperty("/visibleTable", visible );
      		this.getModel("UIControl").setProperty("/visibleInitialsCancelButton", visible );
      		this.getModel("UIControl").setProperty("/visibleInitialsButton", (visible === true ) ? false : true );
      },
      initAndResetForm: function()
      {
      	var data = 
    	 {
    	 	firstName:	"",
    	 	lastName:	"",
    	 	middleName:	""
    	 };
    	 this.setModel(new JSONModel(data),"InitialsForm");
      },
      showMessage: function( message, title, error )
      {
      	var i18n = this.getTools().getText(message);
      	if( i18n )
      	{
      		message = i18n;
      	}
      	var i18nTitle = this.getTools().getText(title);
      	if(i18nTitle)
      	{
      		title = i18nTitle;
      	}
      	
      	jQuery.sap.require("sap.ui.commons.MessageBox");
			var lTitle = title;
			if (lTitle === undefined) {
				lTitle = "Information";
			}
			var type = sap.ui.commons.MessageBox.Icon.INFORMATION;
			
			if( error && error === true )
			{
				type = sap.ui.commons.MessageBox.Icon.ERROR;
			}
			
			// open a fully configured message box
			sap.ui.commons.MessageBox.show(message,
				type,
				lTitle, [sap.ui.commons.MessageBox.Action.OK],
				sap.ui.commons.MessageBox.Action.OK);
      },
      getTools: function()
      {
      	return this._tools;
      },
	  	initApplicationConfiguration: function( )
		{
			var that = this;
			$.ajax
	       (
	           	{
	           		url:   "application-config.json",
	           		async: false,
	           		datatype: "json",
	           		success: function(data)
	           		{
	           			that.appconfig = data;
	           			that.setModel(new JSONModel(data),"AppConfig" );
	           		},
	           		error: function(err){ throw "Application Config could not be loaded";}
	           	}
	       	);
		},
		callForInitials: function()
		{
			var that		= this;
			var formData	= this.getModel("InitialsForm").getData();
			var firstName	= formData.firstName;
			var lastName	= formData.lastName;
			var middleName	= formData.middleName;
			
			//Strip numbers from initials
			firstName		= firstName.replace(/[0-9]/g, '');
			lastName		= lastName.replace(/[0-9]/g, '');   
			middleName		= middleName.replace(/[0-9]/g, '');
			
			//Check for below 5
			var nameLength = 0;
			if( firstName )
			{
				nameLength += firstName.trim().length;
			}
			if( lastName )
			{
				nameLength += lastName.trim().length;
			}
			if( middleName )
			{
				nameLength += middleName.trim().length;
			}
			
			var paramString = "FIRST_NAME='" + firstName +"'";
			paramString		+= "&MIDDLE_NAME='" + middleName + "'";
			paramString     += "&LAST_NAME='" + lastName + "'";
			paramString     += "&NUM_INITIALS=" + this.appconfig.maxNumberOfInitials;
			paramString 	+= "&$format=json";
			
			paramString = encodeURI(paramString);
			
			//Store the data if success
			var success = function(data)
			{
				var results = JSON.parse(data);
				that.setModel( models.createModel( results ), "Initials" );
				that.setTableVisible( true );
			};
			
			var error = function()
			{
				that.setTableVisible( false );
			};
			
			this._requester.getInitials( paramString, success, error );
		}
   });
});