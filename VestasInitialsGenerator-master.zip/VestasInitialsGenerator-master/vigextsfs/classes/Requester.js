//# sourceURL=PictureUploader.js
sap.ui.define([
    "jquery.sap.global",
    "sap/ui/base/Object"
], function(jQuery, BaseObject ) {
    "use strict";

    var Requester = BaseObject.extend("com.vestas.vig.sfsext.apply.classes.Requester", {
        constructor: function( comp )
        {
        	this._comp = comp;
        	this._tunnel_base = this._comp.appconfig.initialsServiceUrl;
        }
    });
    
    Requester.prototype.getInitials = function( params, successCall, errorCall )
    {
    	var that = this;
    	var url = this._tunnel_base + "?" + params;
		
		var innerSuccess = function( data )
		{
			that._comp.getTools().hideBusy(0);
			if( successCall )
			{
				successCall(data);
			}
		};
		
		var innerError = function(err, headers)
		{
			that._comp.getTools().hideBusy(0);
			if( errorCall )
			{
				errorCall(err, headers );
			}
		};
			
		this._comp.getTools().showBusy(0);	
			
		$.ajax({
			  type: "GET",
			  url: url,
			  success: innerSuccess,
			  error:   innerError//,
			  //dataType: "json",
    		  //contentType: "application/json"
			});
    };
    
/*    Requester.prototype.post = function( entity, data, successCB, errorCB )
    {
    	var url 	= this._tunnel_base + entity;
		
			var sucevt = function( successData, headers )
			{
				if( successCB )
				{
					successCB( successData, headers );
				}
			};
			
			var errevt = function(err, headers)
			{
				if( errorCB )
				{
					errorCB(err, headers );
				}
			};
			
			$.ajax({
				  type: "POST",
				  url: url,
				  data: JSON.stringify(data),
				  crossDomain: true,
				  success: sucevt,
				  error:	errevt,
				  contentType: "application/json; charset=utf-8"
				});
    };
    */
    
    return Requester;

});