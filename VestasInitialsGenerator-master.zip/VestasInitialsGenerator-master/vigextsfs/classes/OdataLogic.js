//# sourceURL=PictureUploader.js
sap.ui.define([
    "jquery.sap.global",
    "sap/ui/base/Object"
], function(jQuery, BaseObject ) {
    
    var OdataLogic = BaseObject.extend("com.vestas.vig.sfsext.apply.classes.OdataLogic", {
        constructor: function( comp )
        {
        	this._comp = comp;
        }
    });
    
    return OdataLogic;

});