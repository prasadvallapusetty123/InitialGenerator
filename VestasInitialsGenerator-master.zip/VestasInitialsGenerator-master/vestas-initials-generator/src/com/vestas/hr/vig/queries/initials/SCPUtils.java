package com.vestas.hr.vig.queries.initials;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.olingo.odata2.api.edm.Edm;
import org.apache.olingo.odata2.api.ep.EntityProvider;
import org.apache.olingo.odata2.api.ep.EntityProviderException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.core.connectivity.api.configuration.ConnectivityConfiguration;
import com.sap.core.connectivity.api.configuration.DestinationConfiguration;
import com.vestas.hr.vig.exception.SCPGenericRuntimeException;

public class SCPUtils {

	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(SCPUtils.class);

	private static final String SCP_CONN_CONFIG = "connectivityConfiguration";

	private ConnectivityConfiguration connConf;

	/**
	 * Default constructor, tries to retrieve SCP InitialContext and
	 * ConnectivityConfiguration.
	 */
	public SCPUtils() {
		setConnectivityConfiguration(SCP_CONN_CONFIG);
	}

	public void setConnectivityConfiguration(String name) {
		try {
			// Initialize context
			InitialContext ctx = new InitialContext();
			// Lookup connectivity configuration
			this.connConf = (ConnectivityConfiguration) ctx.lookup("java:comp/env/" + name);
		} catch (NamingException e) {
			LOGGER.error(e.getMessage());
			throw new SCPGenericRuntimeException(e.getMessage(), e);
		}
	}

	public DefaultHttpConnector getDestinationConnector(String destinationName) {
		DestinationConfiguration destConfig = connConf.getConfiguration(destinationName);
		if (destConfig == null) {
			LOGGER.error("Configuration \"{}\" not found", destinationName);
			throw new SCPGenericRuntimeException("Configuration \"" + destinationName + "\" not found");
		}
		
		String serviceUrl = destConfig.getProperty(DestinationConfiguration.DESTINATION_URL);
		
		DefaultHttpConnector conn = new DefaultHttpConnector(serviceUrl);
		if ("BasicAuthentication"
				.equalsIgnoreCase(destConfig.getProperty(DestinationConfiguration.DESTINATION_AUTHENTICATION_TYPE))) {
			conn.setCredentials(destConfig.getProperty(DestinationConfiguration.DESTINATION_USER),
					destConfig.getProperty(DestinationConfiguration.DESTINATION_PASSWORD));
		}
		return conn;
	}
	
	public Edm getServiceMetadata(DefaultHttpConnector connector) throws IOException, EntityProviderException {
		String serviceUri = connector.getURI().toString();
		String tmpUrl = serviceUri;
		if (!"/".equalsIgnoreCase(String.valueOf(tmpUrl.charAt(tmpUrl.length()-1))))
			tmpUrl += "/";
		connector.setUri(tmpUrl+"$metadata");
		connector.addHeader("Accept", "application/xml");
		HttpURLConnection connection = connector.createConnection();
		InputStream inputStream = connector.sendGet(connection).getInputStream();
		Edm edm = EntityProvider.readMetadata(inputStream, false);
		try {
			inputStream.close();
		} catch (IOException e) {
			LOGGER.debug("Stream closed");
		}
		connector.setUri(serviceUri);
		connection.disconnect();
		return edm;
	}
}
