package com.vestas.hr.vig.queries.initials;

import com.vestas.hr.vig.persistence.JPAEntityManagerFactory;
import com.vestas.hr.vig.persistence.appData.VIGBlackList;
import com.vestas.hr.vig.persistence.appData.VIGInitial;
import org.apache.olingo.odata2.api.annotation.edm.EdmFacets;
import org.apache.olingo.odata2.api.annotation.edm.EdmFunctionImport;
import org.apache.olingo.odata2.api.annotation.edm.EdmFunctionImport.HttpMethod;
import org.apache.olingo.odata2.api.annotation.edm.EdmFunctionImport.ReturnType;
import org.apache.olingo.odata2.api.annotation.edm.EdmFunctionImport.ReturnType.Type;
import org.apache.olingo.odata2.api.annotation.edm.EdmFunctionImportParameter;
import org.apache.olingo.odata2.api.edm.Edm;
import org.apache.olingo.odata2.api.ep.EntityProvider;
import org.apache.olingo.odata2.api.ep.EntityProviderException;
import org.apache.olingo.odata2.api.ep.EntityProviderReadProperties;
import org.apache.olingo.odata2.api.ep.feed.ODataFeed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.util.*;

public class Initials {

   private static final Logger LOGGER = LoggerFactory.getLogger(Initials.class);
   private static final String[] FCHARS = {",", "\\.", "\\\\"};
   private static final String UALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   private static final String BLACKLIST_DESTINATION = "InitialsBlacklist";
   private static final String INITIALS_DESTINATION = "InitialsInUse";
   private static final String STREAM_CLOSED = "Stream already closed";
   private static final String ODATA_SELECT = "$select";
   private static final String ODATA_FORMAT = "$format";
   private static final String ODATA_FILTER = "$filter";

   private Hashtable<String, String> htCharacters = new Hashtable<>();
   private List<String> fCharacters = Arrays.asList(FCHARS);
   private TreeSet<String> rejected = new TreeSet<>();
   private TreeSet<String> initialList = new TreeSet<>();
   private DefaultHttpConnector initialsConnector;
   private Edm initialsEdm;
   private DefaultHttpConnector blacklistConnector;
   private Edm blacklistEdm;

   private Random randomizer = new Random();


   @EdmFunctionImport(name = "GET_BLACKLIST", entitySet = "VIGBlackLists", returnType = @ReturnType(type = Type.ENTITY, isCollection = true), httpMethod = HttpMethod.GET)
   public List<VIGBlackList> getBlackList() {
      EntityManager entityManager;
      List<VIGBlackList> blackList = new ArrayList<>();

      String queryString = InitialQueryUtils._initialsBlackList;

      try {
         entityManager = JPAEntityManagerFactory.getEntityManager();

         if (!entityManager.getTransaction().isActive())
            entityManager.getTransaction().begin();

         Query query = entityManager.createQuery(queryString);

         blackList = query.getResultList();

         entityManager.close();

      } catch (NamingException e) {
         LOGGER.error("Error getting blacklist: {}", e);
      }

      return blackList;
   }

   @EdmFunctionImport(name = "GET_INITIALS", entitySet = "VIGInitials", returnType = @ReturnType(type = Type.ENTITY, isCollection = true), httpMethod = HttpMethod.GET)
   public List<VIGInitial> getInitialsForEmployee(
         @EdmFunctionImportParameter(name = "FIRST_NAME", facets = @EdmFacets(nullable = false)) String firstName,
         @EdmFunctionImportParameter(name = "MIDDLE_NAME", facets = @EdmFacets(nullable = true)) String middleName,
         @EdmFunctionImportParameter(name = "LAST_NAME", facets = @EdmFacets(nullable = false)) String lastName,
         @EdmFunctionImportParameter(name = "NUM_INITIALS", facets = @EdmFacets(nullable = true)) Integer numInitials) {
      List<VIGInitial> returnList = new ArrayList<>();

      int num_of_initials = 5;
      if (numInitials.intValue() != 0) {
         num_of_initials = numInitials.intValue();
      }

      final int numberOfCharacters = 5;
      List<String> initialsList = new ArrayList<>();
      this.generateCharactersHT(); // fill in Hashtable with special
      // characters for replacement
      LOGGER.debug("htCharacter: {}", this.htCharacters);

      List<String> nameList = this.prepareNameList(firstName.toUpperCase(), middleName.toUpperCase(),
            lastName.toUpperCase());
      if (!nameList.isEmpty()) {

         int nameListSize = nameList.size();
         String name1 = "";
         String name2 = "";
         String name3 = "";
         String name4 = "";
         int sizeName1 = 0;
         int sizeName2 = 0;
         int sizeName3 = 0;
         int sizeName4 = 0;
         if (nameListSize >= 1) {
            name1 = nameList.get(0);
            sizeName1 = name1.length() - 1;
         }
         if (nameListSize >= 2) {
            name2 = nameList.get(1);
            sizeName2 = name2.length() - 1;
         }
         if (nameListSize >= 3) {
            name3 = nameList.get(2);
            sizeName3 = name3.length() - 1;
         }
         if (nameListSize >= 4) {
            name4 = nameList.get(3);
            sizeName4 = name4.length() - 1;
         }
         int totalNameLength = name1.length() + name2.length() + name3.length() + name4.length();
         int pn = 0;
         if (totalNameLength < numberOfCharacters) {
            // If the total name length is shorter than 5 chars, add default
            // characters...
            String initial = name1 + name2 + name3 + name4 + "ABCDE";
            initial = initial.substring(0, numberOfCharacters);
            initialsList.add(initial);
         } else {
            // General rule for initials is to always take the first letter
            // of each name
            // and then fill in with a single char from each name up to a
            // total length of numberOfCharacters characters.
            int p1 = 0;
            int p2 = 0;
            int p3 = 0;
            int p4 = 0;
            String tempInitial = new String("");
            String tempInitial1 = new String("");
            String tempInitial2 = new String("");
            String tempInitial3 = new String("");
            String tempInitial4;
            switch (nameListSize) {
               case 1:
                  // Exactly 1 name, all letters taken from name 1
                  while (p1 != sizeName1) {
                     p1++;
                     while (pn != sizeName1) {
                        pn++;
                        tempInitial1 = name1.substring(0, 1) + name1.substring(p1, p1 + 1)
                              + name1.substring(pn, pn + 1);
                        initialsList.add(tempInitial);
                     }
                  }

                  break;
               case 2:
                  // Exactly 2 names, take 2 letters from name 1 the rest from
                  // name 2
                  if (sizeName1 == 0) {
                     // Only one letter left in first name
                     tempInitial1 = name1;
                     p2 = 0;
                     while (p2 != sizeName2) {
                        p2++;
                        pn = p2;
                        while (pn != p2) {
                           pn++;
                           tempInitial2 = name2.substring(0, 1) + name2.substring(p2, p2 + 1)
                                 + name2.substring(pn, pn + 1);
                           tempInitial = tempInitial1 + tempInitial2;
                           initialsList.add(tempInitial);
                        }
                     }

                  } else {
                     // Normal situation
                     while (p1 != sizeName1) {
                        p1++;
                        tempInitial1 = name1.substring(0, 1) + name1.substring(p1, p1 + 1);
                        p2 = 0;
                        while (p2 != sizeName2) {
                           p2++;
                           pn = p2;
                           while (pn <= sizeName2) {
                              if (pn == sizeName2) {
                                 tempInitial2 = name2.substring(0, 1) + name2.substring(p2, p2 + 1);
                                 pn++;
                              } else {
                                 pn++;
                                 tempInitial2 = name2.substring(0, 1) + name2.substring(p2, p2 + 1)
                                       + name2.substring(pn, pn + 1);
                              }
                              tempInitial = tempInitial1 + tempInitial2;
                              initialsList.add(tempInitial);
                           }
                        }
                     }
                  }

                  break;
               case 3:

                  // New rules for 3 names needed to be hardcoded according to
                  // this logic instead:
                  // First name|Middle name|Surname
                  // 1st + 2nd |1st |1st + 2nd
                  // 1st + 2nd |1st |1st + 3rd
                  // 1st + 2nd |1st |1st + 4th
                  // 1st + 2nd |1st |1st + 5th
                  // 1st + 3rd |1st |1st + 2nd
                  // 1st + 3rd |1st |1st + 3rd
                  // 1st + 3rd |1st |1st + 4th
                  // 1st + 3rd |1st |1st + 5th
                  // 1st |1st + 2nd |1st + 2nd
                  // 1st |1st + 3rd |1st + 2nd
                  // 1st |1st + 4th |1st + 2nd
                  // 1st |1st + 5th |1st + 2nd
                  // 1st |1st + 2nd |1st + 3rd
                  // 1st |1st + 2nd |1st + 4th
                  // 1st |1st + 2nd |1st + 5th
                  // 1st + 2nd |1st + 2nd |1st
                  // 1st + 2nd |1st + 3rd |1st
                  // 1st + 2nd |1st + 4th |1st
                  // 1st + 2nd |1st + 5th |1st

                  // 1st + 2nd |1st |1st + 2nd
                  if (sizeName1 >= 1 && sizeName3 >= 1) {
                     tempInitial = name1.substring(0, 2) + name2.substring(0, 1) + name3.substring(0, 2);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 2nd |1st |1st + 3rd
                  if (sizeName1 >= 1 && sizeName3 >= 2) {
                     tempInitial = name1.substring(0, 2) + name2.substring(0, 1) + name3.substring(0, 1)
                           + name3.substring(1, 2);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 2nd |1st |1st + 4th
                  if (sizeName1 >= 1 && sizeName3 >= 3) {
                     tempInitial = name1.substring(0, 2) + name2.substring(0, 1) + name3.substring(0, 1)
                           + name3.substring(2, 3);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 2nd |1st |1st + 5th
                  if (sizeName1 >= 1 && sizeName3 >= 4) {
                     tempInitial = name1.substring(0, 2) + name2.substring(0, 1) + name3.substring(0, 1)
                           + name3.substring(3, 4);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 3rd |1st |1st + 2nd
                  if (sizeName1 >= 2 && sizeName3 >= 1) {
                     tempInitial = name1.substring(0, 1) + name1.substring(2, 3) + name2.substring(0, 1)
                           + name3.substring(0, 2);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 3rd |1st |1st + 3rd
                  if (sizeName1 >= 2 && sizeName3 >= 2) {
                     tempInitial = name1.substring(0, 1) + name1.substring(2, 3) + name2.substring(0, 1)
                           + name3.substring(0, 1) + name3.substring(2, 3);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 3rd |1st |1st + 4th
                  if (sizeName1 >= 2 && sizeName3 >= 3) {
                     tempInitial = name1.substring(0, 1) + name1.substring(2, 3) + name2.substring(0, 1)
                           + name3.substring(0, 1) + name3.substring(3, 4);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 3rd |1st |1st + 5th
                  if (sizeName1 >= 2 && sizeName3 >= 4) {
                     tempInitial = name1.substring(0, 1) + name1.substring(2, 3) + name2.substring(0, 1)
                           + name3.substring(0, 1) + name3.substring(4, 5);
                     initialsList.add(tempInitial);
                  }

                  // 1st |1st + 2nd |1st + 2nd
                  if (sizeName2 >= 1 && sizeName3 >= 1) {
                     tempInitial = name1.substring(0, 1) + name2.substring(0, 2) + name3.substring(0, 2);
                     initialsList.add(tempInitial);
                  }

                  // 1st |1st + 3rd |1st + 2nd
                  if (sizeName2 >= 2 && sizeName3 >= 1) {
                     tempInitial = name1.substring(0, 1) + name2.substring(0, 1) + name2.substring(2, 3)
                           + name3.substring(0, 2);
                     initialsList.add(tempInitial);
                  }

                  // 1st |1st + 4th |1st + 2nd
                  if (sizeName2 >= 3 && sizeName3 >= 1) {
                     tempInitial = name1.substring(0, 1) + name2.substring(0, 1) + name2.substring(3, 4)
                           + name3.substring(0, 2);
                     initialsList.add(tempInitial);
                  }

                  // 1st |1st + 5th |1st + 2nd
                  if (sizeName2 >= 4 && sizeName3 >= 1) {
                     tempInitial = name1.substring(0, 1) + name2.substring(0, 1) + name2.substring(4, 5)
                           + name3.substring(0, 2);
                     initialsList.add(tempInitial);
                  }

                  // 1st |1st + 2nd |1st + 3rd
                  if (sizeName2 >= 1 && sizeName3 >= 2) {
                     tempInitial = name1.substring(0, 1) + name2.substring(0, 2) + name3.substring(0, 1)
                           + name3.substring(2, 3);
                     initialsList.add(tempInitial);
                  }

                  // 1st |1st + 2nd |1st + 4th
                  if (sizeName2 >= 1 && sizeName3 >= 3) {
                     tempInitial = name1.substring(0, 1) + name2.substring(0, 2) + name3.substring(0, 1)
                           + name3.substring(3, 4);
                     initialsList.add(tempInitial);
                  }

                  // 1st |1st + 2nd |1st + 5th
                  if (sizeName2 >= 1 && sizeName3 >= 4) {
                     tempInitial = name1.substring(0, 1) + name2.substring(0, 2) + name3.substring(0, 1)
                           + name3.substring(4, 5);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 2nd |1st + 2nd |1st
                  if (sizeName1 >= 1 && sizeName2 >= 1) {
                     tempInitial = name1.substring(0, 2) + name2.substring(0, 2) + name3.substring(0, 1);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 2nd |1st + 3rd |1st
                  if (sizeName1 >= 1 && sizeName2 >= 2) {
                     tempInitial = name1.substring(0, 2) + name2.substring(0, 1) + name2.substring(2, 3)
                           + name3.substring(0, 1);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 2nd |1st + 4th |1st
                  if (sizeName1 >= 1 && sizeName2 >= 3) {
                     tempInitial = name1.substring(0, 2) + name2.substring(0, 1) + name2.substring(3, 4)
                           + name3.substring(0, 1);
                     initialsList.add(tempInitial);
                  }

                  // 1st + 2nd |1st + 5th |1st
                  if (sizeName1 >= 1 && sizeName2 >= 4) {
                     tempInitial = name1.substring(0, 2) + name2.substring(0, 1) + name2.substring(4, 5)
                           + name3.substring(0, 1);
                     initialsList.add(tempInitial);
                  }

                  break;
               default:

                  // 4 or more names, 4 first letters + 1 additional
                  tempInitial1 = name1.substring(0, 1);
                  tempInitial2 = name2.substring(0, 1);
                  tempInitial3 = name3.substring(0, 1);
                  while (p4 != sizeName4) {
                     p4++;
                     tempInitial4 = name4.substring(0, 1) + name4.substring(p4, p4 + 1);
                     tempInitial = tempInitial1 + tempInitial2 + tempInitial3 + tempInitial4;
                     initialsList.add(tempInitial);
                  }

                  tempInitial1 = name1.substring(0, 1);
                  tempInitial2 = name2.substring(0, 1);
                  tempInitial4 = name4.substring(0, 1);
                  while (p3 != sizeName3) {
                     p3++;
                     tempInitial3 = name3.substring(0, 1) + name3.substring(p3, p3 + 1);
                     tempInitial = tempInitial1 + tempInitial2 + tempInitial3 + tempInitial4;
                     initialsList.add(tempInitial);

                  }

                  tempInitial1 = name1.substring(0, 1);
                  tempInitial3 = name3.substring(0, 1);
                  tempInitial4 = name4.substring(0, 1);
                  while (p2 != sizeName2) {
                     p2++;
                     tempInitial2 = name2.substring(0, 1) + name2.substring(p2, p2 + 1);
                     tempInitial = tempInitial1 + tempInitial2 + tempInitial3 + tempInitial4;
                     initialsList.add(tempInitial);

                  }

                  tempInitial2 = name2.substring(0, 1);
                  tempInitial3 = name3.substring(0, 1);
                  tempInitial4 = name4.substring(0, 1);
                  while (p1 != sizeName1) {
                     p1++;
                     tempInitial1 = name1.substring(0, 1) + name1.substring(p1, p1 + 1);
                     tempInitial = tempInitial1 + tempInitial2 + tempInitial3 + tempInitial4;
                     initialsList.add(tempInitial);

                  }

                  break;
            }
         }

         String defaultInitial = "";
         if (!initialsList.isEmpty()) {
            defaultInitial = initialsList.get(0);
         }

         Collections.sort(initialsList);

         Set<String> uniqueList = new HashSet<>();
         for (String initials : initialsList) {
            if (!uniqueList.contains(initials)) {
               uniqueList.add(initials);
            }
         }

         List<String> returnListString = new ArrayList<>();
         if (sizeName1 >= 1) {
            // Create the temp table and append the logical/normal initials
            // to the original
            // table to give it first position
            returnListString.add(defaultInitial);
            // Append initials to the original table in the order of the 2
            // first letters in
            // the first name
            List<String> tempInitialList = new ArrayList<>(initialsList);
            for (String initials : tempInitialList) {
               if (initials.substring(0, 2).equals(name1.substring(0, 2))) {
                  if (initials.equals(defaultInitial)) {
                     initialsList.remove(initials);
                  } else {
                     if (initials.length() == numberOfCharacters) {
                        returnListString.add(initials);
                        initialsList.remove(initials);
                     }
                  }

               }
            }
            // Append the rest of the table to the original table
            returnListString.addAll(initialsList);

         }

         pn = 0;
         char c = ' ';
         String alphabet = UALPHABET;
         for (int i = 0; i < returnListString.size(); i++) {
            // If the full name is short, the length of the initials may be
            // below
            // numberOfCharacters,
            // therefore add additional characters to reach the wanted
            // length of
            // numberOfCharacters
            String initials = returnListString.get(i);
            if (initials.length() < numberOfCharacters) {
               if (c != 'Z') {
                  c = alphabet.charAt(pn);
                  pn++;
               }
               initials = initials + c;
            }

            // TODO: Check if initials exist already in another employee -
            // query SF for the
            // list
            // if it isn't used in another employee:
            // TODO: Check against the blacklist
            // if it's not blacklisted, append to the resulting list
            VIGInitial vInitials = new VIGInitial();
            vInitials.setInitials(initials);
            returnList.add(vInitials);

            if (i == num_of_initials - 1) {
               break;
            }

         }

         pn = 0;
         // It was not possible to generate all the wanted initials
         // Add new ones containing A-Z adds until satisfied
         Random gen = new Random();
         while (returnList.size() < num_of_initials) {
            String initial = returnListString.get(0).substring(0, 4);
            pn = gen.nextInt(alphabet.length());
            c = alphabet.charAt(pn);
            initial = new StringBuilder(initial).insert(Math.min(initial.length(), gen.nextInt(6)), c).toString();

            // TODO: Check if initials exist already in another employee -
            // query SF for the
            // list
            // if it isn't used in another employee:
            // TODO: Check against the blacklist
            // if it's not blacklisted, append to the resulting list
            VIGInitial vInitials = new VIGInitial();
            vInitials.setInitials(initial);
            if (!returnList.contains(vInitials))
               returnList.add(vInitials);
         }

      }
      LOGGER.debug("END returnList: {}", returnList);
      return returnList;
   }

   private List<String> prepareNameList(String firstName, String middleName, String lastName) {
      List<String> nameList = new ArrayList<String>();

      String fullName = firstName + " " + middleName + " " + lastName;
      if (fullName.indexOf('-') >= 0) {
         fullName = fullName.replaceAll("-", " ");
      }

      StringTokenizer st = new StringTokenizer(fullName, " ");
      while (st.hasMoreTokens()) {
         String nextToken = st.nextToken();
         // YPA_TRANSLATE
         String translatedName = this.translateName(nextToken);

         nameList.add(translatedName);
      }
      if (nameList.size() == 0) {
         nameList.add(fullName);
      }
      LOGGER.debug("nameList: {}", nameList);
      return nameList;
   }

   private String translateName(String name) {
      String translatedName = "";
      for (char ch : name.toCharArray()) {
         LOGGER.debug("Checking character: {}", ch);
         if (htCharacters.containsKey(String.valueOf(ch))) {
            LOGGER.debug("Found character: {}", ch);
            LOGGER.debug("character value: {}", htCharacters.get(String.valueOf(ch)));
            translatedName = translatedName + htCharacters.get(String.valueOf(ch));
         } else {
            translatedName = translatedName + ch;
         }
      }

      return translatedName;
   }

   private void generateCharactersHT() {

      htCharacters.put(new String("Ā"), new String("A"));
      htCharacters.put(new String("Ă"), new String("A"));
      htCharacters.put(new String("Ą"), new String("A"));
      htCharacters.put(new String("Ć"), new String("C"));
      htCharacters.put(new String("Ĉ"), new String("C"));
      htCharacters.put(new String("Ċ"), new String("C"));
      htCharacters.put(new String("Č"), new String("C"));
      htCharacters.put(new String("Ď"), new String("D"));
      htCharacters.put(new String("Đ"), new String("D"));
      htCharacters.put(new String("Ē"), new String("E"));
      htCharacters.put(new String("Ĕ"), new String("E"));
      htCharacters.put(new String("Ė"), new String("E"));
      htCharacters.put(new String("Ę"), new String("E"));
      htCharacters.put(new String("Ě"), new String("E"));
      htCharacters.put(new String("Ĝ"), new String("G"));
      htCharacters.put(new String("Ğ"), new String("G"));
      htCharacters.put(new String("Ġ"), new String("G"));
      htCharacters.put(new String("Ģ"), new String("G"));
      htCharacters.put(new String("$"), new String("S"));
      htCharacters.put(new String("Ĥ"), new String("H"));
      htCharacters.put(new String("Ħ"), new String("H"));
      htCharacters.put(new String("Ĩ"), new String("I"));
      htCharacters.put(new String("∩"), new String("N"));
      htCharacters.put(new String("Ī"), new String("I"));
      htCharacters.put(new String("Ĭ"), new String("I"));
      htCharacters.put(new String("Į"), new String("I"));
      htCharacters.put(new String("İ"), new String("I"));
      htCharacters.put(new String("Ĵ"), new String("J"));
      htCharacters.put(new String("Ķ"), new String("K"));
      htCharacters.put(new String("Ĺ"), new String("L"));
      htCharacters.put(new String("Ļ"), new String("L"));
      htCharacters.put(new String("Ľ"), new String("L"));
      htCharacters.put(new String("Ƚ"), new String("L"));
      htCharacters.put(new String("@"), new String("A"));
      htCharacters.put(new String("Ł"), new String("L"));
      htCharacters.put(new String("Ń"), new String("N"));
      htCharacters.put(new String("Ƀ"), new String("B"));
      htCharacters.put(new String("Ņ"), new String("N"));
      htCharacters.put(new String("Ň"), new String("N"));
      htCharacters.put(new String("I"), new String("I"));
      htCharacters.put(new String("Ō"), new String("O"));
      htCharacters.put(new String("Ŏ"), new String("O"));
      htCharacters.put(new String("Ő"), new String("O"));
      htCharacters.put(new String("Œ"), new String("C"));
      htCharacters.put(new String("Ŕ"), new String("R"));
      htCharacters.put(new String("Ŗ"), new String("R"));
      htCharacters.put(new String("Ř"), new String("R"));
      htCharacters.put(new String("Ś"), new String("S"));
      htCharacters.put(new String("Ŝ"), new String("S"));
      htCharacters.put(new String("Ş"), new String("S"));
      htCharacters.put(new String("Š"), new String("S"));
      htCharacters.put(new String("ɡ"), new String("G"));
      htCharacters.put(new String("Ţ"), new String("T"));
      htCharacters.put(new String("Ť"), new String("T"));
      htCharacters.put(new String("Ŧ"), new String("T"));
      htCharacters.put(new String("Ũ"), new String("U"));
      htCharacters.put(new String("Ū"), new String("U"));
      htCharacters.put(new String("Ŭ"), new String("U"));
      htCharacters.put(new String("Ů"), new String("U"));
      htCharacters.put(new String("Ű"), new String("U"));
      htCharacters.put(new String("Ų"), new String("U"));
      htCharacters.put(new String("Ŵ"), new String("W"));
      htCharacters.put(new String("Ŷ"), new String("Y"));
      htCharacters.put(new String("Ÿ"), new String("Y"));
      htCharacters.put(new String("Ź"), new String("Z"));
      htCharacters.put(new String("Ż"), new String("Z"));
      htCharacters.put(new String("Ž"), new String("Z"));
      htCharacters.put(new String("ⁿ"), new String("N"));
      htCharacters.put(new String("Ɖ"), new String("D"));
      htCharacters.put(new String("Ƒ"), new String("F"));
      htCharacters.put(new String("Α"), new String("A"));
      htCharacters.put(new String("Γ"), new String("G"));
      htCharacters.put(new String("Δ"), new String("D"));
      htCharacters.put(new String("Ε"), new String("E"));
      htCharacters.put(new String("Ɨ"), new String("I"));
      htCharacters.put(new String("Θ"), new String("T"));
      htCharacters.put(new String("Μ"), new String("Μ"));
      htCharacters.put(new String("Ɵ"), new String("O"));
      htCharacters.put(new String("Ơ"), new String("O"));
      htCharacters.put(new String("Π"), new String("P"));
      htCharacters.put(new String("¡"), new String("I"));
      htCharacters.put(new String("¢"), new String("C"));
      htCharacters.put(new String("£"), new String("L"));
      htCharacters.put(new String("Σ"), new String("S"));
      htCharacters.put(new String("¤"), new String("O"));
      htCharacters.put(new String("Τ"), new String("T"));
      htCharacters.put(new String("¥"), new String("Y"));
      htCharacters.put(new String("Φ"), new String("F"));
      htCharacters.put(new String("©"), new String("C"));
      htCharacters.put(new String("Ω"), new String("O"));
      htCharacters.put(new String("ª"), new String("A"));
      htCharacters.put(new String("ƫ"), new String("T"));
      htCharacters.put(new String("Ʈ"), new String("T"));
      htCharacters.put(new String("Ư"), new String("U"));
      htCharacters.put(new String("Ƶ"), new String("Z"));
      htCharacters.put(new String("Һ"), new String("H"));
      htCharacters.put(new String("À"), new String("A"));
      htCharacters.put(new String("Á"), new String("A"));
      htCharacters.put(new String("Â"), new String("A"));
      htCharacters.put(new String("Ã"), new String("A"));
      htCharacters.put(new String("Ä"), new String("A"));
      htCharacters.put(new String("Å"), new String("A"));
      htCharacters.put(new String("Æ"), new String("A"));
      htCharacters.put(new String("Ç"), new String("C"));
      htCharacters.put(new String("È"), new String("E"));
      htCharacters.put(new String("É"), new String("E"));
      htCharacters.put(new String("Ê"), new String("E"));
      htCharacters.put(new String("Ë"), new String("E"));
      htCharacters.put(new String("Ì"), new String("I"));
      htCharacters.put(new String("Í"), new String("I"));
      htCharacters.put(new String("Ǎ"), new String("A"));
      htCharacters.put(new String("Î"), new String("I"));
      htCharacters.put(new String("Ï"), new String("I"));
      htCharacters.put(new String("Ǐ"), new String("I"));
      htCharacters.put(new String("Ð"), new String("D"));
      htCharacters.put(new String("Ñ"), new String("N"));
      htCharacters.put(new String("Ǒ"), new String("O"));
      htCharacters.put(new String("Ò"), new String("O"));
      htCharacters.put(new String("Ó"), new String("O"));
      htCharacters.put(new String("Ǔ"), new String("U"));
      htCharacters.put(new String("Ô"), new String("O"));
      htCharacters.put(new String("Õ"), new String("O"));
      htCharacters.put(new String("Ǖ"), new String("U"));
      htCharacters.put(new String("Ö"), new String("O"));
      htCharacters.put(new String("×"), new String("X"));
      htCharacters.put(new String("Ǘ"), new String("U"));
      htCharacters.put(new String("Ø"), new String("O"));
      htCharacters.put(new String("Ù"), new String("U"));
      htCharacters.put(new String("Ǚ"), new String("U"));
      htCharacters.put(new String("Ú"), new String("U"));
      htCharacters.put(new String("Û"), new String("U"));
      htCharacters.put(new String("Ǜ"), new String("U"));
      htCharacters.put(new String("Ü"), new String("U"));
      htCharacters.put(new String("Ý"), new String("Y"));
      htCharacters.put(new String("Þ"), new String("D"));
      htCharacters.put(new String("Ǟ"), new String("A"));
      htCharacters.put(new String("ß"), new String("S"));
      htCharacters.put(new String("Ǥ"), new String("G"));
      htCharacters.put(new String("Ǧ"), new String("G"));
      htCharacters.put(new String("Ǩ"), new String("K"));
      htCharacters.put(new String("Ǫ"), new String("O"));
      htCharacters.put(new String("Ǭ"), new String("O"));
      htCharacters.put(new String("ǰ"), new String("J"));

   }

   @EdmFunctionImport(name = "GET_ORDERED_INITIALS", entitySet = "VIGInitials", returnType = @ReturnType(type = Type.ENTITY, isCollection = true), httpMethod = HttpMethod.GET)
   public List<VIGInitial> getGeneratedInitialsForEmployee(
         @EdmFunctionImportParameter(name = "FIRST_NAME", facets = @EdmFacets(nullable = false)) String firstName,
         @EdmFunctionImportParameter(name = "MIDDLE_NAME", facets = @EdmFacets(nullable = true)) String middleName,
         @EdmFunctionImportParameter(name = "LAST_NAME", facets = @EdmFacets(nullable = false)) String lastName,
         @EdmFunctionImportParameter(name = "NUM_INITIALS", facets = @EdmFacets(nullable = true)) Integer numInitials) {

      List<VIGInitial> returnList = new ArrayList<VIGInitial>();
      SCPUtils util = new SCPUtils();
      //Initialize initials connector destination
      initializeInitialsDestination(util);
      //Initialize blacklist connection destination
      initializeBlacklistDestination(new SCPUtils());

      int num_of_initials = 5;
      //Validate if amout of initials was specified
      if (numInitials.intValue() != 0) {
         num_of_initials = numInitials.intValue();
      }

      //Vestas requires initials to have 5 characters
      final int numberOfCharacters = 5;

      // fill in Hashtable with special
      // characters for replacement
      this.generateCharactersHT();
      LOGGER.debug("htCharacter: {}", this.htCharacters);

      //Prepare the provided names for generation
      firstName = prepareName(firstName);
      middleName = prepareName(middleName);
      lastName = prepareName(lastName);

      firstName += middleName;

      //Calculate each name segment size on the generated initials
      int firstSize = firstName.length();
      int lastSize = lastName.length();

      if (firstSize > lastSize) {
         firstSize = (lastSize > 1) ? (numberOfCharacters - 2) : (numberOfCharacters - 1);
         lastSize = numberOfCharacters - firstSize;
      } else {
         lastSize = (firstSize > 1) ? (numberOfCharacters - 2) : (numberOfCharacters - 1);
         firstSize = numberOfCharacters - lastSize;
      }

      firstSize = getSmallerSize(firstSize, firstName);
      lastSize = getSmallerSize(lastSize, lastName);

      //Define counter to prevent infinite loop
      int counter = 0;

      //Repeat until number of initials is reached or safeguard of 100 loops occurred
      while (initialList.size() < num_of_initials && counter <= 100) {

         StringBuilder sb = new StringBuilder();

         //Check the number of loops and change each segment size
         //At 20 change each segment size
         if (counter == 20) {

            if (firstSize > lastSize) {
               if ((firstSize + lastSize) <= numberOfCharacters && lastSize > 1) {
                  lastSize--;
                  firstSize = getSmallerSize(firstSize + 1, firstName);
               }
            } else {
               if ((firstSize + lastSize) <= numberOfCharacters && firstSize > 1) {
                  firstSize--;
                  lastSize = getSmallerSize(lastSize + 1, lastName);
               }
            }
         }

         //Get first segment
         sb.append(getNameSegment(firstName, firstSize));
         //Get last segment
         sb.append(getNameSegment(lastName, lastSize));

         //Fill with random letters
         if (sb.length() < numberOfCharacters) {
            sb.append(getRandomString((numberOfCharacters - sb.length())));
         }

         //Validate generated initial
         String initial = sb.toString();
         if (validateInitials(initial)) {
            initialList.add(initial);
         } else {
            rejected.add(initial);
         }
         counter++;
      }

      //Fill result list
      for (String initial : initialList) {
         VIGInitial vInitials = new VIGInitial();
         vInitials.setInitials(initial);
         returnList.add(vInitials);
      }

      LOGGER.debug("END returnList: {}", returnList);
      LOGGER.debug("Counter: {}, Initials size: {}, rejected size: {}", counter, initialList.size(), rejected.size());
      return returnList;
   }

   private String getNameSegment(String name, int size) {
      StringBuilder sb = new StringBuilder();
      if (name.length() > 0) {
         sb.append(name.charAt(0));
         if (name.length() > 1) {
            int pos = 0;
            int range;
            while (sb.length() < size && pos < (name.length() - 1)) {
               if (name.length() > 4) {
                  if (pos == 0) {
                     range = (name.length() / 2);
                  } else {
                     range = name.length() - pos;
                  }
               } else {
                  range = name.length() - pos;
               }
               int j = randomizer.nextInt(range - 1) + 1;
               pos += j;
               if (pos < name.length())
                  sb.append(name.charAt(pos));
            }
         }

      }
      return sb.toString();
   }

   private String getRandomString(int size) {
      StringBuilder sb = new StringBuilder();
      while (sb.length() < size) {
         int pos = randomizer.nextInt(UALPHABET.length());
         sb.append(UALPHABET.charAt(pos));
      }
      return sb.toString();
   }

   private int getSmallerSize(int size, String name) {
      return (name.length() > size) ? size : name.length();
   }

   private String prepareName(String name) {
      if (name != null && !"".equals(name)) {
         name = name.toUpperCase();

         // YPA_TRANSLATE
         name = translateName(name);

         name = name.replaceAll("-", " ");

         // Filter out forbidden characters
         for (String c : fCharacters) {
            name = name.replaceAll(c, "");
         }

         name = name.replaceAll(" ", "");
      } else {
         name = "";
      }
      return name;
   }

   private boolean validateInitials(String initials) {
      boolean result = true;
      if (initialList.contains(initials) || rejected.contains(initials) ||
            validateInitialsInUse(initials) || validateBlacklistInUse(initials))
         result = false;
      return result;
   }

   private boolean validateBlacklistInUse(String initials) {
      boolean result = false;
      URI tempUri = blacklistConnector.getURI();
      blacklistConnector.addQueryParameter(ODATA_FILTER, "INIT eq '" + initials + "'");
      HttpURLConnection connection = null;
      InputStream response = null;
      try {
         blacklistConnector.getHeaders().remove("Accept");
         connection = blacklistConnector.createConnection();
         response = blacklistConnector.sendGet(connection).getInputStream();
         ODataFeed feed = EntityProvider.readFeed("application/json", blacklistEdm.getDefaultEntityContainer().getEntitySet("cust_Y_INITGEN"), response, EntityProviderReadProperties.init().build());
         if (!feed.getEntries().isEmpty())
            result = true;
      } catch (Exception e) {
         LOGGER.error("Error checking blacklist", e);
         result = true;
      } finally {
         try {
            if (response != null) {
               response.close();
            }
         } catch (Exception e) {
            LOGGER.debug(STREAM_CLOSED);
         }
      }
      blacklistConnector.setUri(tempUri);
      LOGGER.debug("Initial {} is blacklisted: {}", initials, result);
      return result;
   }

   private boolean validateInitialsInUse(String initials) {
      boolean result = false;
      URI tempUri = initialsConnector.getURI();
      initialsConnector.addQueryParameter(ODATA_FILTER, "status in 'active','inactive' and username eq '" + initials + "'");
      HttpURLConnection connection = null;
      InputStream response = null;
      try {
         initialsConnector.getHeaders().remove("Accept");
         connection = initialsConnector.createConnection();
         response = initialsConnector.sendGet(connection).getInputStream();
         ODataFeed feed = EntityProvider.readFeed("application/json", initialsEdm.getDefaultEntityContainer().getEntitySet("User"), response, EntityProviderReadProperties.init().build());
         if (!feed.getEntries().isEmpty())
            result = true;
      } catch (Exception e) {
         LOGGER.error("Error checking initial", e);
         result = true;
      } finally {
         try {
            if (response != null) {
               response.close();
            }
         } catch (Exception e) {
            LOGGER.debug(STREAM_CLOSED);
         }
      }
      initialsConnector.setUri(tempUri);
      LOGGER.debug("Initial {} is in use: {}", initials, result);
      return result;
   }

   private void initializeInitialsDestination(SCPUtils helper) {
      this.initialsConnector = helper.getDestinationConnector(INITIALS_DESTINATION);
      try {
         this.initialsEdm = helper.getServiceMetadata(initialsConnector);
         this.initialsConnector.addQueryParameter(ODATA_FORMAT, "json");
         this.initialsConnector.addQueryParameter(ODATA_SELECT, "username");
      } catch (EntityProviderException | IOException e) {
         LOGGER.error("Error initializing initials components.", e);
      }
   }

   private void initializeBlacklistDestination(SCPUtils helper) {
      this.blacklistConnector = helper.getDestinationConnector(BLACKLIST_DESTINATION);
      try {
         this.blacklistEdm = helper.getServiceMetadata(blacklistConnector);
         this.blacklistConnector.addQueryParameter(ODATA_FORMAT, "json");
         this.blacklistConnector.addQueryParameter(ODATA_SELECT, "INIT");
      } catch (EntityProviderException | IOException e) {
         LOGGER.error("Error initializing blacklist components.", e);
      }
   }
}
