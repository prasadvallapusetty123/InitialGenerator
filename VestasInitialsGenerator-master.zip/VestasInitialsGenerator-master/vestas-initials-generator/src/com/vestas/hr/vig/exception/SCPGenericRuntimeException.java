package com.vestas.hr.vig.exception;

import java.util.Locale;

import org.apache.olingo.odata2.api.commons.HttpStatusCodes;
import org.apache.olingo.odata2.api.exception.ODataRuntimeApplicationException;

public class SCPGenericRuntimeException extends ODataRuntimeApplicationException {

	private static final long serialVersionUID = 1L;
	
	public SCPGenericRuntimeException(String message) {
		super(message, Locale.getDefault());
	}
	
	public SCPGenericRuntimeException(String message, HttpStatusCodes status) {
		super(message, Locale.getDefault(), status);
	}
	
	public SCPGenericRuntimeException(String message, Throwable e) {
		super(message, Locale.getDefault(), e);
	}

	public SCPGenericRuntimeException(String message, HttpStatusCodes status, Throwable e) {
		super(message, Locale.getDefault(), status, e);
	}

}
