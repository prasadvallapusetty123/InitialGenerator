package com.vestas.hr.vig.servlet;

import com.google.gson.Gson;
import com.vestas.hr.vig.persistence.appData.VIGInitial;
import com.vestas.hr.vig.queries.initials.Initials;
import org.apache.olingo.odata2.api.edm.EdmException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class VIGInitialsGenerator extends HttpServlet {

   @Override
   protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      String firstName = getParameterValue("FIRST_NAME", req);
      String middleName = getParameterValue("MIDDLE_NAME", req);
      String lastName = getParameterValue("LAST_NAME", req);
      String strNumInitials = getParameterValue("NUM_INITIALS", req);

      if (firstName == null || lastName == null || "".equalsIgnoreCase(firstName) || "".equalsIgnoreCase(firstName)) {
         resp.getOutputStream().print("{\"error\":\"Must provide FIRST_NAME and LAST_NAME, MIDDLE_NAME and NUM_INITIALS are optional.");
      } else {
         List<VIGInitial> result = new ArrayList<>();
         Integer numInitials = 5;
         try {
            numInitials = Integer.parseInt(strNumInitials);
         } catch (Exception e) {

         }

         Initials initialsProcessor = new Initials();
            result = initialsProcessor.getGeneratedInitialsForEmployee(firstName, middleName, lastName, numInitials);
            Gson gson = new Gson();
            resp.getOutputStream().print(gson.toJson(result));
      }
   }

   private String getParameterValue(String parameterName, HttpServletRequest req) {
      String value = req.getParameter(parameterName);
      if (value == null) {
         value = "";
      } else {
         value = value.replace("'","");
      }
      return value;
   }
}
