package com.vestas.hr.vig.persistence.appData;

import static javax.persistence.TemporalType.DATE;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Date;

import javax.persistence.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;



@Entity
@Table(name = "VIGINITIAL")

public class VIGInitial implements Serializable {
	private static final Logger LOGGER = LoggerFactory.getLogger(VIGInitial.class);
	private static final long serialVersionUID = 1L;

	public VIGInitial() {
	}

	@Id
	@Column(name = "ID")
	@GeneratedValue
	private long id;

	@Column(name = "CLIENT_ID")
	private String clientId;

	@Column(name = "EMPLOYEE_ID")
	private String employeeId;

	@Column(name = "FIRST_NAME")
	private String firstName;

	@Column(name = "MIDDLE_NAME")
	private String middleName;

	@Column(name = "LAST_NAME")
	private String lastName;

	@Column(name = "INITIALS")
	private String initials;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_ON")
	@Temporal(DATE)
	private Date createdOn;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "MODIFIED_ON")
	@Temporal(DATE)
	private Date modifiedAt;

	@Column(name = "DELETE_DATE")
	@Temporal(DATE)
	private Date deleteDate;

	@JsonProperty("ID")
	public long getId() {
		return id;
	}

	@JsonProperty("ID")
	public void setId(long id) {
		this.id = id;
	}

	@JsonProperty("CLIENT_ID")
	public String getClientId() {
		return clientId;
	}

	@JsonProperty("CLIENT_ID")
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	@JsonProperty("EMPLOYEE_ID")
	public String getEmployeeId() {
		return employeeId;
	}

	@JsonProperty("EMPLOYEE_ID")
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	@JsonProperty("FIRST_NAME")
	public String getFirstName() {
		return firstName;
	}

	@JsonProperty("FIRST_NAME")
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@JsonProperty("MIDDLE_NAME")
	public String getMiddleName() {
		return middleName;
	}

	@JsonProperty("MIDDLE_NAME")
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	@JsonProperty("LAST_NAME")
	public String getLastName() {
		return lastName;
	}

	@JsonProperty("LAST_NAME")
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@JsonProperty("INITIALS")
	public String getInitials() {
		return initials;
	}

	@JsonProperty("INITIALS")
	public void setInitials(String initials) {
		this.initials = initials;
	}

	@JsonProperty("CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}

	@JsonProperty("CREATED_BY")
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@JsonProperty("CREATED_ON")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	public Date getCreatedOn() {
		return createdOn;
	}

	@JsonProperty("CREATED_ON")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	public void setCreatedAt(Date createdOn) {
		this.createdOn = createdOn;
	}

	@JsonProperty("MODIFIED_BY")
	public String getModifiedBy() {
		return modifiedBy;
	}

	@JsonProperty("MODIFIED_BY")
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	@JsonProperty("MODIFIED_AT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	public Date getModifiedAt() {
		return modifiedAt;
	}

	@JsonProperty("MODIFIED_AT")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	public void setModifiedAt(Date modifiedAt) {
		this.modifiedAt = modifiedAt;
	}

	@JsonProperty("DELETE_DATE")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	public Date getDeleteDate() {
		return deleteDate;
	}

	@JsonProperty("DELETE_DATE")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	
	


	@Override
	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VIGInitial other = (VIGInitial) obj;		
		if (initials == null) {
			if (other.initials != null)
				return false;
		} else if (!initials.equals(other.initials))
			return false;		
		return true;
	}
	
	@Override
	public String toString() {
		return "VIGInitial [id=" + id + ", initials=" + initials + "]";
	}

	public static Comparator<VIGInitial> sortByInitials() {
		Comparator<VIGInitial> comp = new Comparator<VIGInitial>() {
			@Override
			public int compare(VIGInitial vi1, VIGInitial vi2) {				
				return vi1.getInitials().compareTo(vi2.getInitials());
			}
		};
		return comp;
	}

}