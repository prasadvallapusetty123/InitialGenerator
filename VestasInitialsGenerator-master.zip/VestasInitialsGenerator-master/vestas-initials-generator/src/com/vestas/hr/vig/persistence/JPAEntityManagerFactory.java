package com.vestas.hr.vig.persistence;

import java.util.HashMap;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.sql.DataSource;

import org.eclipse.persistence.config.PersistenceUnitProperties;

public class JPAEntityManagerFactory {
	
	private static EntityManagerFactory entityManagerFactory = null;
	private static EntityManager entityManager = null;
	
	public static synchronized EntityManagerFactory getEntityManagerFactory() throws NamingException {

		if (entityManagerFactory == null) {
			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup(PersistenceUtils.DATA_SOURCE_NAME_DEFAULT);
			
			Map<String,Object> properties = new HashMap<String,Object>();
			properties.put(PersistenceUnitProperties.NON_JTA_DATASOURCE, ds);
//			properties.put("javax.persistence.lock.timeout", 2000);
			entityManagerFactory = Persistence.createEntityManagerFactory(PersistenceUtils.PERSISTENCE_UNIT_NAME, properties);
			
			DummyData dummy = new DummyData(entityManagerFactory.createEntityManager());
			dummy.makeDummyData();
			
		}

		return entityManagerFactory;

	}
	
	public static synchronized EntityManager getEntityManager() throws NamingException{
				
		if(entityManager == null || !entityManager.isOpen() ){
			
			entityManager = getEntityManagerFactory().createEntityManager();
			
		}
		
		return entityManager;
		
	}
	
	public static synchronized void closeEntityManager() throws NamingException{
		
		if(entityManager != null){
			entityManager.clear();
			entityManager.close();
		}
		
	}
		
}
