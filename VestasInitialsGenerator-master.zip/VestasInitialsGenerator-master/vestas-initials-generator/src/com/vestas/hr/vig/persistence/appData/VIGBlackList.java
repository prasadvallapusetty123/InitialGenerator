package com.vestas.hr.vig.persistence.appData;

import static javax.persistence.TemporalType.DATE;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import org.eclipse.persistence.annotations.Cache;
import org.eclipse.persistence.annotations.CacheType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;


@Entity
@Table(name = "VIGBLACKLIST")
@Cache(type = CacheType.FULL)
@NamedQueries({
    @NamedQuery(name="VIGBlackList.getAll",
                query="SELECT b FROM VIGBlackList b"),
    @NamedQuery(name="VIGBlackList.getByInitial",
    			query="SELECT b FROM VIGBlackList b WHERE b.initials = :initial"),
})
public class VIGBlackList implements Serializable {

	private static final long serialVersionUID = 1L;

	public VIGBlackList() {
	}

	@Id
	@Column(name = "ID")
	@GeneratedValue
	private long id;
	

	@Column(name = "CLIENT_ID")
	private String clientId    ;
	
	@Column(name = "INITIALS")
	private String initials     ;
	
	@Column(name = "CREATED_BY")
	private String createdBy   ;
	
	@Column(name = "CREATED_ON")
	@Temporal(DATE)
	private Date createdOn   ;
	
	@Column(name = "MODIFIED_BY")
	private String modifiedBy  ;
	
	@Column(name = "MODIFIED_ON")
	@Temporal(DATE)
	private Date modifiedAt  ;

	
	@JsonProperty("ID")
	public long getId() {
		return id;
	}
	
	@JsonProperty("ID")
	public void setId(long id) {
		this.id = id;
	}

	@JsonProperty("CLIENT_ID")
	public String getClientId() {
		return clientId;
	}

	@JsonProperty("CLIENT_ID")
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	

	@JsonProperty("INITIALS")
	public String getInitials() {
		return initials;
	}

	@JsonProperty("INITIALS")
	public void setInitials(String initials) {
		this.initials = initials;
	}

	@JsonProperty("CREATED_BY")
	public String getCreatedBy() {
		return createdBy;
	}

	@JsonProperty("CREATED_BY")
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@JsonProperty("CREATED_ON")
	@JsonFormat(
		      shape = JsonFormat.Shape.STRING,
		      pattern = "dd-MM-yyyy hh:mm:ss")
	public Date getCreatedOn() {
		return createdOn;
	}

	@JsonProperty("CREATED_ON")
	@JsonFormat(
		      shape = JsonFormat.Shape.STRING,
		      pattern = "dd-MM-yyyy hh:mm:ss")
	public void setCreatedAt(Date createdOn) {
		this.createdOn = createdOn;
	}

	@JsonProperty("MODIFIED_BY")
	public String getModifiedBy() {
		return modifiedBy;
	}

	@JsonProperty("MODIFIED_BY")
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	@JsonProperty("MODIFIED_AT")
	@JsonFormat(
		      shape = JsonFormat.Shape.STRING,
		      pattern = "dd-MM-yyyy hh:mm:ss")
	public Date getModifiedAt() {
		return modifiedAt;
	}

	@JsonProperty("MODIFIED_AT")
	@JsonFormat(
		      shape = JsonFormat.Shape.STRING,
		      pattern = "dd-MM-yyyy hh:mm:ss")
	public void setModifiedAt(Date modifiedAt) {
		this.modifiedAt = modifiedAt;
	}	

}