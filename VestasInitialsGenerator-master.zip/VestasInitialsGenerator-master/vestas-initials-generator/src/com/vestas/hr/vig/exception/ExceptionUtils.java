package com.vestas.hr.vig.exception;

public class ExceptionUtils {

}
