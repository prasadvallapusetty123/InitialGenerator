package com.vestas.hr.vig.queries.initials;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DefaultHttpConnector {
	
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LoggerFactory.getLogger(DefaultHttpConnector.class);

	private URI uri;
	private Map<String, String> headers = new HashMap<String, String>();
	private String username;
	private String password;

	public DefaultHttpConnector() {
	}

	/**
	 * Creates a connector and attempts to create the provided URI instance.
	 * @param uri
	 */
	public DefaultHttpConnector(String uri) {
		setUri(uri);
	}

	/**
	 * Sets the provided URI.
	 * @param uri
	 */
	public void setUri(String uri) {
		try {
			this.uri = new URI(uri);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Sets the provided URI.
	 * @param uri
	 */
	public void setUri(URI uri) {
		this.uri = uri;
	}
	
	public URI getURI() {
		return this.uri;
	}

	/**
	 * Gets the headers map configured for the connection.
	 * @return
	 */
	public Map<String, String> getHeaders() {
		return this.headers;
	}

	/**
	 * Configures the headers map to be set on the connection.
	 * @param requestHeaders
	 * 		The headers map
	 */
	public void setHeaders(Map<String, String> requestHeaders) {
		this.headers = requestHeaders;
	}

	/**
	 * Adds a header the configuration map
	 * @param key
	 * 		The header key
	 * @param value
	 * 		The header value
	 */
	public void addHeader(String key, String value) {
		if (key != null && !headers.containsKey(key))
			this.headers.put(key, value);
	}

	/**
	 * Sets the credentials to be used for basic authentication.
	 * The Authorization header will only be set if these are configured or if
	 * it is added through setHeaders or addHeader
	 * 
	 * @param username
	 * 		The login user
	 * @param password
	 * 		The login password
	 */
	public void setCredentials(String username, String password) {
		this.username = username;
		this.password = password;
	}

	/**
	 * Creates an HttURLConnection object based on the current configuration.
	 * The created connection is not connected.
	 * 
	 * @return
	 * 		The connection instance (not connected)
	 * @throws IOException
	 */
	public HttpURLConnection createConnection() throws IOException {
		LOGGER.info("Creating connection to {}", uri.toString());
		HttpURLConnection conn = (HttpURLConnection) uri.toURL().openConnection();

		if (username != null && password != null) {
			StringBuffer sb = new StringBuffer("Basic ");
			sb.append(Base64.encodeBase64String(new String(username + ":" + password).getBytes()));
			conn.addRequestProperty("Authorization", sb.toString());
			LOGGER.debug("Added header to HTTP connection: Authorization={}", sb.toString());
		}

		for (String headerKey : headers.keySet()) {
			conn.addRequestProperty(headerKey, headers.get(headerKey));
			LOGGER.debug("Added header to HTTP connection: {}={}", new Object[] {headerKey, headers.get(headerKey)});
		}

		return conn;
	}

	/**
	 * Send an HTTP GET request based on the connection information, and validates the response
	 * status before returning the connection. It only returns the connection if the status is
	 * successful.
	 * 
	 * @param connection
	 * 		The connection to be used on the GET request
	 * @return
	 * 		A validated connection with response
	 * @throws IOException
	 */
	public HttpURLConnection sendGet(HttpURLConnection connection) throws IOException {
		connection.setRequestMethod("GET");
//		connection.addRequestProperty("Method", "GET");
		LOGGER.info("Sending HTTP GET request");
		connection.connect();
		validateConnection(connection);
		return connection;
	}

	/**
	 * Validates connection response status.
	 * @param connection
	 * 		The connection to validate
	 * @throws IOException
	 */
	public void validateConnection(HttpURLConnection connection) throws IOException {
		LOGGER.debug("Validating connection response status");
		try {
			Status connStatus = Response.Status.fromStatusCode(connection.getResponseCode());
			if (connStatus == null || connStatus.getFamily() != Response.Status.Family.SUCCESSFUL) {
				String errorMsg = "HTTP request failed with error " + connection.getResponseCode() + "-"
						+ connection.getResponseMessage();
				LOGGER.error(errorMsg);
				throw new RuntimeException(errorMsg);
			}
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
			throw e;
		}
		LOGGER.debug("Connection status OK.");
	}
	
	/**
	 * Adds a query parameter to the configured URI. Parameter is not set if URI is null.
	 * 
	 * @param key
	 * 		The query parameter key (not null)
	 * @param value
	 * 		The query parameter value
	 */
	public void addQueryParameter(String key, String value) {
		if (uri != null && key != null)
			this.uri = UriBuilder.fromUri(uri).queryParam(key, value).build();
	}
}
