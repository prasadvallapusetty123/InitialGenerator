package com.vestas.hr.vig.exception;

public enum PersistenceErrors {

	// Generic errors (format: 1xxx)
	CREATE_ENTITY_ERROR("1000","Error creating Entity."),
	
	// Document related errors (format: 2xxx)
	DOC_TYPE_NOT_FOUND_ERROR("2000","Did not receive valid document type."),
	DOC_STATUS_NOT_FOUND_ERROR("2001","Did not receive valid Status."),
	DOC_TYPE_OBLIGATORY_ERROR("2002","Document Type is obligatory."),
	DOC_STATUS_OBLIGATORY_ERROR("2003","Document Status is Obligatory."),
	// DocumentContent related errors (format: 21xx)
	FILE_MD5_CHECK_ERROR("2100","Failed to validate the file received against the MD5 signature."),
	FILE_NOT_RECEIVED_ERROR("2101","Didn't receive the Document File."),
	;
	
	private String errorCode;
	private String errorMessage;
	
	private PersistenceErrors(String errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
	
	public String getErrorCode() {
		return this.errorCode;
	}
	
	public String getErrorMessage() {
		return this.errorMessage;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("[");
		builder.append(this.errorCode);
		builder.append("][");
		builder.append(this.errorMessage);
		builder.append("]");
		return builder.toString();
	}
}
