package com.vestas.hr.vig.servlet;

import java.io.InputStream;
import java.util.List;

import org.apache.olingo.odata2.api.batch.BatchHandler;
import org.apache.olingo.odata2.api.batch.BatchResponsePart;
import org.apache.olingo.odata2.api.commons.HttpStatusCodes;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.api.processor.ODataContext;
import org.apache.olingo.odata2.api.processor.ODataProcessor;
import org.apache.olingo.odata2.api.processor.ODataRequest;
import org.apache.olingo.odata2.api.processor.ODataResponse;
import org.apache.olingo.odata2.api.processor.ODataSingleProcessor;
import org.apache.olingo.odata2.api.uri.info.DeleteUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetComplexPropertyUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntityCountUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntityLinkCountUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntityLinkUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetCountUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetLinksCountUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetLinksUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntitySetUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetEntityUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetFunctionImportUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetMediaResourceUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetMetadataUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetServiceDocumentUriInfo;
import org.apache.olingo.odata2.api.uri.info.GetSimplePropertyUriInfo;
import org.apache.olingo.odata2.api.uri.info.PostUriInfo;
import org.apache.olingo.odata2.api.uri.info.PutMergePatchUriInfo;
import org.apache.olingo.odata2.jpa.processor.api.ODataJPAContext;
import org.apache.olingo.odata2.jpa.processor.api.ODataJPAProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vestas.hr.vig.appConfig.DomainUtils;
import com.vestas.hr.vig.persistence.appData.VIGInitial;

public class CustomODataJPAProcessor extends ODataJPAProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomODataJPAProcessor.class);

	private ODataSingleProcessor odataJPAProcessor;

	public CustomODataJPAProcessor(ODataJPAContext oDataJPAContext) {
		super(oDataJPAContext);
		// TODO Auto-generated constructor stub
	}

	@Override
	public ODataResponse readEntitySet(final GetEntitySetUriInfo uriParserResultView, final String contentType)
			throws ODataException {

		/* Pre Process Step */
		preprocess();

		List<Object> jpaEntities = jpaProcessor.process(uriParserResultView);

		/* Post Process Step */
		postProcess();

		ODataResponse oDataResponse = responseBuilder.build(uriParserResultView, jpaEntities, contentType);

		return oDataResponse;
	}

	@Override
	public ODataResponse readMetadata(GetMetadataUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse out = this.odataJPAProcessor.readMetadata(uriInfo, contentType);
		postProcess();
		return out;
	}

	@Override
	public ODataResponse createEntity(PostUriInfo uriInfo, InputStream content, String requestContentType,
			String contentType) throws ODataException {

		preprocess();

		ODataResponse out = this.odataJPAProcessor.createEntity(uriInfo, content, requestContentType, contentType);

		if ("VIGINITIAL".equalsIgnoreCase(uriInfo.getTargetType().getName())) {
//			VIGLogging dbLog = new VIGLogging();
//			dbLog.setMasterLog(getUserNameFromContext(), "POST", "VIGInitial created " + getDocIDFromContext() +
//					" " + getConfidentialFromContext() , DomainUtils.ODATA, null, getDocFromOut(out) );
//			dbLog.closeAndSaveLog();
		}
		postProcess();
		return out;

	}

	@Override
	public ODataResponse createEntityLink(PostUriInfo uriInfo, InputStream content, String requestContentType,
			String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse out = this.odataJPAProcessor.createEntityLink(uriInfo, content, requestContentType, contentType);
		postProcess();
		return out;

	}

	@Override
	public ODataResponse countEntityLinks(GetEntitySetLinksCountUriInfo uriInfo, String contentType)
			throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse out = this.odataJPAProcessor.countEntityLinks(uriInfo, contentType);
		postProcess();
		return out;

	}

	@Override
	public ODataResponse countEntitySet(GetEntitySetCountUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse out = this.odataJPAProcessor.countEntitySet(uriInfo, contentType);
		postProcess();
		return out;

	}

	@Override
	public ODataResponse deleteEntityLink(DeleteUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub
		// return this.odataJPAProcessor.deleteEntityLink(uriInfo, contentType);

		preprocess();
		ODataResponse out = this.odataJPAProcessor.deleteEntityLink(uriInfo, contentType);// super.deleteEntityLink(uriInfo,
																							// contentType);
		postProcess();
		return out;

	}

	@Override
	public ODataResponse deleteEntityMedia(DeleteUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub
		// return this.odataJPAProcessor.deleteEntityMedia(uriInfo,
		// contentType);

		preprocess();
		ODataResponse out = this.odataJPAProcessor.deleteEntityMedia(uriInfo, contentType);// super.deleteEntityMedia(uriInfo,
																							// contentType);
		postProcess();
		return out;

	}

	@Override
	public ODataResponse deleteEntitySimplePropertyValue(DeleteUriInfo uriInfo, String contentType)
			throws ODataException {
		// TODO Auto-generated method stub
		// return
		// this.odataJPAProcessor.deleteEntitySimplePropertyValue(uriInfo,
		// contentType);

		preprocess();
		ODataResponse out = this.odataJPAProcessor.deleteEntitySimplePropertyValue(uriInfo, contentType);// super.deleteEntitySimplePropertyValue(uriInfo,
																											// contentType);
		postProcess();
		return out;

	}

	@Override
	public ODataResponse deleteEntity(DeleteUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub
		preprocess();
		ODataResponse out;	
		
		if ("VIGINITIAL".equalsIgnoreCase(uriInfo.getTargetType().getName())) {
//			VIGLogging dbLog = new VIGLogging();
//			dbLog.setMasterLog(getUserNameFromContext(), "DELETE", "VIGInitial delete attempt " + getDocIDFromContext() +
//					" " + getConfidentialFromContext(), DomainUtils.ODATA, null);
//			dbLog.closeAndSaveLog();
			out = ODataResponse.entity(new Exception("VIGInitials cannot be deleted directly."))
					.status(HttpStatusCodes.METHOD_NOT_ALLOWED).build();
		} else {
			out = this.odataJPAProcessor.deleteEntity(uriInfo, contentType);
		}
		
		postProcess();
		return out;
	}

	@Override
	public ODataResponse executeBatch(BatchHandler handler, String contentType, InputStream content)
			throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.executeBatch(handler, contentType, content);
		postProcess();
		return ret;

	}

	@Override
	public BatchResponsePart executeChangeSet(BatchHandler handler, List<ODataRequest> requests) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		BatchResponsePart ret = this.odataJPAProcessor.executeChangeSet(handler, requests);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse executeFunctionImport(GetFunctionImportUriInfo uriInfo, String contentType)
			throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.executeFunctionImport(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse executeFunctionImportValue(GetFunctionImportUriInfo uriInfo, String contentType)
			throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.executeFunctionImportValue(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse existsEntity(GetEntityCountUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.existsEntity(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse existsEntityLink(GetEntityLinkCountUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.existsEntityLink(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataContext getContext() {
		// TODO Auto-generated method stub

		preprocess();
		ODataContext ret = this.odataJPAProcessor.getContext();
		postProcess();
		return ret;

	}

	@Override
	public List<String> getCustomContentTypes(Class<? extends ODataProcessor> processorFeature) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		List<String> ret = this.odataJPAProcessor.getCustomContentTypes(processorFeature);
		postProcess();
		return ret;

	}

	@Override
	public ODataJPAContext getOdataJPAContext() {
		// TODO Auto-generated method stub

		preprocess();
		ODataJPAContext ret = ((ODataJPAProcessor) this.odataJPAProcessor).getOdataJPAContext();
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse readEntity(GetEntityUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.readEntity(uriInfo, contentType);

		if ("VIGINITIAL".equalsIgnoreCase(uriInfo.getTargetType().getName())) {
//			VIGLogging dbLog = new VIGLogging();
//			dbLog.setMasterLog(getUserNameFromContext(), "GET", "VIGInitial read " + getDocIDFromContext() +
//					" " + getConfidentialFromContext(), DomainUtils.ODATA, null);
//			dbLog.closeAndSaveLog();
		}
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse readEntityComplexProperty(GetComplexPropertyUriInfo uriInfo, String contentType)
			throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.readEntityComplexProperty(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse readEntityLink(GetEntityLinkUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.readEntityLink(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse readEntityLinks(GetEntitySetLinksUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.readEntityLinks(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse readEntityMedia(GetMediaResourceUriInfo uriInfo, String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.readEntityMedia(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse readEntitySimpleProperty(GetSimplePropertyUriInfo uriInfo, String contentType)
			throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.readEntitySimpleProperty(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse readEntitySimplePropertyValue(GetSimplePropertyUriInfo uriInfo, String contentType)
			throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.readEntitySimplePropertyValue(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse readServiceDocument(GetServiceDocumentUriInfo uriInfo, String contentType)
			throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.readServiceDocument(uriInfo, contentType);
		postProcess();
		return ret;

	}

	@Override
	public void setContext(ODataContext context) {
		// TODO Auto-generated method stub
		preprocess();
		this.odataJPAProcessor.setContext(context);
		postProcess();
	}

	@Override
	public void setOdataJPAContext(ODataJPAContext odataJPAContext) {
		// TODO Auto-generated method stub
		preprocess();
		((ODataJPAProcessor) this.odataJPAProcessor).setOdataJPAContext(odataJPAContext);
		postProcess();
	}

	@Override
	public ODataResponse updateEntity(PutMergePatchUriInfo uriInfo, InputStream content, String requestContentType,
			boolean merge, String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.updateEntity(uriInfo, content, requestContentType, merge,
				contentType);

		if ("VIGINITIAL".equalsIgnoreCase(uriInfo.getTargetType().getName())) {
//			VIGLogging dbLog = new VIGLogging();
//			dbLog.setMasterLog(getUserNameFromContext(), "PUT", "VIGInitial updated "+ getDocIDFromContext() +
//					" " + getConfidentialFromContext(), DomainUtils.ODATA, null, getDocFromOut(ret));
//			dbLog.closeAndSaveLog();
		}
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse updateEntityComplexProperty(PutMergePatchUriInfo uriInfo, InputStream content,
			String requestContentType, boolean merge, String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.updateEntityComplexProperty(uriInfo, content, requestContentType,
				merge, contentType);
		postProcess();
		return ret;

	}

	@Override
	public ODataResponse updateEntityLink(PutMergePatchUriInfo uriInfo, InputStream content, String requestContentType,
			String contentType) throws ODataException {
		// TODO Auto-generated method stub

		preprocess();
		ODataResponse ret = this.odataJPAProcessor.updateEntityLink(uriInfo, content, requestContentType, contentType);
		postProcess();
		return ret;
	}

	@Override
	public ODataResponse updateEntityMedia(PutMergePatchUriInfo uriInfo, InputStream content, String requestContentType,
			String contentType) throws ODataException {
		// TODO Auto-generated method stub
		preprocess();
		ODataResponse ret = this.odataJPAProcessor.updateEntityMedia(uriInfo, content, requestContentType, contentType);
		postProcess();

		return ret;
	}

	@Override
	public ODataResponse updateEntitySimpleProperty(PutMergePatchUriInfo uriInfo, InputStream content,
			String requestContentType, String contentType) throws ODataException {
		// TODO Auto-generated method stub
		preprocess();
		ODataResponse ret = this.odataJPAProcessor.updateEntitySimpleProperty(uriInfo, content, requestContentType,
				contentType);
		postProcess();

		return ret;
	}

	@Override
	public ODataResponse updateEntitySimplePropertyValue(PutMergePatchUriInfo uriInfo, InputStream content,
			String requestContentType, String contentType) throws ODataException {
		// TODO Auto-generated method stub
		preprocess();
		ODataResponse ret = this.odataJPAProcessor.updateEntitySimplePropertyValue(uriInfo, content, requestContentType,
				contentType);
		postProcess();

		return ret;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		((ODataJPAProcessor) this.odataJPAProcessor).close();
	}

	private void preprocess() {
		// TODO Auto-generated method stub

	}

	private void postProcess() {
		// TODO Auto-generated method stub
		int i = 0;
		i++;
	}

	public void setDefaultODataJPAProcessor(ODataSingleProcessor odataJPAProcessor) {
		this.odataJPAProcessor = odataJPAProcessor;
	}

	
	private String getUserNameFromContext(){
		
		String ret = "Unknown";
		if(SessionContext.getLocalRequestuser()!=null){
			ret = SessionContext.getLocalRequestuser().getName();
		}
		
		return ret;
		
	}
	
	private String getDocIDFromContext(){
		
		String ret = "Unknown";
		if(SessionContext.getLocaldocId()!=null){
			ret = SessionContext.getLocaldocId().toString();
		}
		
		return ret;		
		
	}
	
	private String getConfidentialFromContext(){
		
		String ret = "Unknown";
		if(SessionContext.getLocalConfidential()!=null){
			ret = SessionContext.getLocalConfidential().toString();
		}
		
		return ret;		
		
	}	
	
	private VIGInitial getDocFromOut(ODataResponse out){
		
		VIGInitial ret = null;
		
		try{
			ret = (VIGInitial) out.getEntity();
		}catch (Exception e) {
			// return null
		}
		
		return ret;
		
	}
	
}
