package com.vestas.hr.vig.persistence;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.vestas.hr.vig.persistence.appData.VIGBlackList;
import com.vestas.hr.vig.persistence.appData.VIGInitial;

public class DummyData {
	private static final Logger LOGGER = LoggerFactory.getLogger(VIGBlackList.class);
	
	private EntityManager entityManager;
	private VIGBlackList blackList;

	
	public DummyData(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public void makeDummyData(){
		
		
		if(isCreateDataNeeded()){
			try{
				makeBlackListDummyData();				
				
				JPAEntityManagerFactory.closeEntityManager();
				
//			entityManager.close();
				
			}catch (Exception e) {
				
				LOGGER.error("Error loading initial data {} detail- {}", e.getClass().getName(),
						e.getMessage());			
				
				if(e.getCause()!=null){
					
					LOGGER.error("Cause{}", e.getCause().getMessage());	
					
					
				}
			}
			
		}
		
	}

	private boolean isCreateDataNeeded() {
		
		boolean ret = true;
		
		TypedQuery<VIGBlackList> query = entityManager.createNamedQuery("VIGBlackList.getAll", VIGBlackList.class);
		List<VIGBlackList> test = query.getResultList();
		
		if(test != null && test.size()>0){
			ret = false;
		}
		return ret;
	}

	
	private void makeBlackListDummyData( ) throws Exception{
		
//		entityManager.getTransaction().begin();
		
		VIGBlackList bl = new VIGBlackList();
		bl.setClientId(UUID.randomUUID().toString());
		bl.setInitials("BASIC");
		bl.setCreatedBy("PRO");
		bl.setCreatedAt(new Date());
				
		PersistenceUtils.persistEntity(bl, entityManager);
//		entityManager.getTransaction().commit();
	}	
	
}
