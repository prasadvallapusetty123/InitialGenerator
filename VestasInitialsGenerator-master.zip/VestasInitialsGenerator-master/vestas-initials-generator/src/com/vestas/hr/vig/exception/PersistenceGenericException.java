/**
 * 
 */
package com.vestas.hr.vig.exception;

import java.util.Locale;

import org.apache.olingo.odata2.api.exception.ODataRuntimeApplicationException;

/**
 * Custom class that extends {@link Exception} for storage related exception.
 * It add the following attributes:
 * - resourceID
 * - errorCode
 * 
 * @author jpi
 *
 */
public class PersistenceGenericException extends ODataRuntimeApplicationException 
{

	private static final long serialVersionUID = 1L;
	private String errorCode = null;
	private String resourceID = null;
	private String errorMessageAux = "";
	private PersistenceErrors error;

	/**
	 * Returns the resource ID of the document in use when the exception occurred.
	 * @return
	 */
	public String getResourceID() {
		return resourceID;
	}

	/**
	 * Sets the resource ID of the document in use when the exception occurred.
	 * @param resourceID
	 */
	public void setResourceID(String resourceID) {
		this.resourceID = resourceID;
	}

	/**
	 * Returns the custom error code specified for the occurrence.
	 * @return
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * Set the custom error code specified for the occurrence.
	 * @param errorCode
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Custom object to handle storage related exception.
	 * 
	 * @param message
	 */
	public PersistenceGenericException(String errorMessage) {
		super(errorMessage, Locale.ENGLISH);
//		super(errorMessage);
		this.errorMessageAux = errorMessage;
	}
	
	/**
	 * Custom object to handle storage related exceptions.
	 * 
	 * @param errorCode
	 * @param errorMessage
	 * @param resourceID
	 * @param sourceException
	 */
	public PersistenceGenericException(String errorCode, String errorMessage, String resourceID, Exception sourceException) {
		super(errorMessage + sourceException.getMessage(), Locale.ENGLISH, sourceException.getCause());
//		super(errorMessage + sourceException.getMessage(), sourceException.getCause());
		this.errorMessageAux = errorMessage;
	}
	
	/**
	 * Custom object to handle storage related exceptions.
	 * @param error
	 * @param resourceID
	 * @param sourceException
	 */
	public PersistenceGenericException(PersistenceErrors error, String resourceID, Exception sourceException) {
		super(error.getErrorMessage() + sourceException.getMessage(), Locale.ENGLISH, sourceException.getCause());
//		super(error.getErrorMessage() + sourceException.getMessage(), sourceException.getCause());
		this.errorCode = error.getErrorCode();
		this.error = error;
	}
	
	/**
	 * Custom object to handle storage related exceptions.
	 * @param error
	 * @param resourceID
	 * @param sourceException
	 */
	public PersistenceGenericException(PersistenceErrors error, Exception sourceException) {
		super(error.getErrorMessage() + sourceException.getMessage(), Locale.ENGLISH, sourceException.getCause());
//		super(error.getErrorMessage() + sourceException.getMessage(), sourceException.getCause());
		this.errorCode = error.getErrorCode();
		this.error = error;
	}
	
	/**
	 * 
	 * @param error
	 */
	public PersistenceGenericException(PersistenceErrors error) {
		super(error.getErrorMessage(), Locale.ENGLISH);
//		super(error.getErrorMessage());
		this.errorCode = error.getErrorCode();
		this.error = error;
	}
	
	/**
	 * Returns a custom message of the exception with the format:
	 * [resource id][error code][error message]
	 * 
	 * @return
	 */
	@Override
	public String toString() {
		String ret = "";
		
		if(this.resourceID!=null && !this.resourceID.isEmpty()){
			
			ret = ret + "["+this.resourceID+"]";
			
		}
		
		ret = ret + "["+this.errorCode+"]";
		
		if(this.error!=null){
			ret = ret + "["+this.error.getErrorMessage()+"]";
			
		}
		else{
			ret = ret + "["+this.errorMessageAux+"]";
			
		}

		return ret;
		
	}
	
	@Override
	public String getMessage() {
		String ret = "";
		
		if(this.resourceID!=null && !this.resourceID.isEmpty()){
			
			ret = ret + "["+this.resourceID+"]";
			
		}
		
		ret = ret + "["+this.errorCode+"]";
		
		if(this.error!=null){
			ret = ret + "["+this.error.getErrorMessage()+"]";
			
		}
		else{
			ret = ret + "["+this.errorMessageAux+"]";
			
		}

		return ret;
	}
	
}
