package com.vestas.hr.vig.exception;

import org.apache.olingo.odata2.api.ep.EntityProvider;
import org.apache.olingo.odata2.api.exception.ODataApplicationException;
import org.apache.olingo.odata2.api.processor.ODataErrorCallback;
import org.apache.olingo.odata2.api.processor.ODataErrorContext;
import org.apache.olingo.odata2.api.processor.ODataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vestas.hr.vig.persistence.appData.VIGInitial;

public class PersistenceErrorCallback implements ODataErrorCallback  {

	private static final Logger LOGGER = LoggerFactory.getLogger(VIGInitial.class);
	
	  @Override
	  public ODataResponse handleError(ODataErrorContext context) throws ODataApplicationException {
		  
		  
		  
		  String message = context.getException().getClass().getName() + ":" + context.getMessage();
		  if(context.getException().getCause()!=null){
			  message = message + "[Cause:"+ context.getException().getCause().getMessage() +"]";
			  
		  }
			  
		  LOGGER.error(message);
	      return EntityProvider.writeErrorDocument(context);
	      
	  }
	  
}
