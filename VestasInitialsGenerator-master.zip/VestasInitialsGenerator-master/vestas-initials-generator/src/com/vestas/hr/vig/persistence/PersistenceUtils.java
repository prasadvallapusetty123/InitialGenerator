package com.vestas.hr.vig.persistence;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

import javax.naming.NamingException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.apache.olingo.odata2.jpa.processor.api.ODataJPAContext;

import com.vestas.hr.vig.appConfig.AppGeneralConfigUtils;

public class PersistenceUtils {

	protected static final String PERSISTENCE_UNIT_NAME = "VIG";
	protected static final String DATA_SOURCE_NAME_HANA = "java:comp/env/jdbc/dshana";
	protected static final String DATA_SOURCE_NAME_DEFAULT = "java:comp/env/jdbc/DefaultDB";

	public static final Date getDateFromString2(String date) {
		Date ret = null;
		SimpleDateFormat dt = new SimpleDateFormat(AppGeneralConfigUtils.DATE_FORMAT);

		if (date == null || date.isEmpty()) {
			return ret;
		}

		try {
			ret = dt.parse(date);
		} catch (ParseException e) {
			ret = new Date();
		}

		return ret;
	}

	public static final String getStringFromDate2(Date date) {
		String ret = "";

		SimpleDateFormat dt = new SimpleDateFormat(AppGeneralConfigUtils.DATE_FORMAT);

		if (date != null) {
			ret = dt.format(date);
		}

		return ret;
	}

	public static void setODataJPAContext(ODataJPAContext oDatJPAContext) throws NamingException {

		EntityManagerFactory emf = JPAEntityManagerFactory.getEntityManagerFactory();
		oDatJPAContext.setEntityManagerFactory(emf);
		oDatJPAContext.setPersistenceUnitName(PERSISTENCE_UNIT_NAME);

	}

	public static void invalidateCacheEntity(Class<?> entityType, Object primaryKey) {
		try {
			JPAEntityManagerFactory.getEntityManagerFactory().getCache().evict(entityType, primaryKey);
			JPAEntityManagerFactory.getEntityManagerFactory().getCache().evictAll();

		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void mergeEntity(Object o) throws Exception {

		EntityManager entityManager;

		if (o == null) {
			return;
		}

		entityManager = JPAEntityManagerFactory.getEntityManager();

		if (!entityManager.getTransaction().isActive()) {
			entityManager.getTransaction().begin();
		}

		// lockEntity(o, entityManager);

		// try{

		entityManager.merge(o);

		entityManager.getTransaction().commit();

		// }catch (Exception e) {
		//
		// unlockEntity(o, entityManager);
		//
		// if(entityManager.getTransaction() != null &&
		// entityManager.getTransaction().isActive()){
		// entityManager.getTransaction().rollback();
		// }
		//
		// throw e;
		// }

		// unlockEntity(o, entityManager);

	}

	public static void mergeEntity(Collection<Object> oList) throws Exception {

		EntityManager entityManager;
		// Collection<Object> lockedObjects = new ArrayList<Object>();

		if (oList == null || oList.isEmpty()) {
			return;
		}

		entityManager = JPAEntityManagerFactory.getEntityManager();

		if (!entityManager.getTransaction().isActive()) {
			entityManager.getTransaction().begin();
		}

		// try{
		//
		// for(Object o : oList){
		// lockEntity(o, entityManager);
		// lockedObjects.add(o);
		//
		// }
		//
		// }catch (Exception e) {
		//
		// for(Object o : lockedObjects){
		// unlockEntity(o, entityManager);
		// }
		//
		// if(entityManager.getTransaction() != null &&
		// entityManager.getTransaction().isActive()){
		// entityManager.getTransaction().rollback();
		// }
		//
		// throw e;
		//
		// }

		try {

			for (Object o : oList) {
				entityManager.merge(o);
			}

			entityManager.getTransaction().commit();
		} catch (Exception e) {

			// for(Object o : lockedObjects){
			// unlockEntity(o, entityManager);
			// }

			throw e;
		}

		// for(Object o : lockedObjects){
		// unlockEntity(o, entityManager);
		// }

	}

	public static void persistEntity(Object o) throws Exception {

		EntityManager entityManager;

		if (o == null) {
			return;
		}

		entityManager = JPAEntityManagerFactory.getEntityManager();

		if (!entityManager.getTransaction().isActive()) {
			entityManager.getTransaction().begin();
		}

		// lockEntity(o, entityManager);

		// try{

		entityManager.persist(o);

		entityManager.getTransaction().commit();

		// }catch (Exception e) {
		//
		// unlockEntity(o, entityManager);
		//
		// if(entityManager.getTransaction() != null &&
		// entityManager.getTransaction().isActive()){
		// entityManager.getTransaction().rollback();
		// }
		//
		// throw e;
		// }

		// unlockEntity(o, entityManager);

	}

	public static void persistEntity(Collection<Object> oList) throws Exception {

		EntityManager entityManager;
		// Collection<Object> lockedObjects = new ArrayList<Object>();

		if (oList == null || oList.isEmpty()) {
			return;
		}

		entityManager = JPAEntityManagerFactory.getEntityManager();

		if (!entityManager.getTransaction().isActive()) {
			entityManager.getTransaction().begin();
		}

		// try{
		//
		// for(Object o : oList){
		// lockEntity(o, entityManager);
		// lockedObjects.add(o);
		//
		// }
		//
		// }catch (Exception e) {
		//
		// for(Object o : lockedObjects){
		// unlockEntity(o, entityManager);
		// }
		//
		// if(entityManager.getTransaction() != null &&
		// entityManager.getTransaction().isActive()){
		// entityManager.getTransaction().rollback();
		// }
		//
		// throw e;
		//
		// }

		try {

			for (Object o : oList) {
				entityManager.persist(o);
			}

			entityManager.getTransaction().commit();
		} catch (Exception e) {

			// for(Object o : lockedObjects){
			// unlockEntity(o, entityManager);
			// }

			throw e;
		}

		// for(Object o : lockedObjects){
		// unlockEntity(o, entityManager);
		// }

	}

	public static void persistEntity(Collection<Object> oList, EntityManager entityManager) throws Exception {

		// Collection<Object> lockedObjects = new ArrayList<Object>();

		if (oList == null || oList.isEmpty() || entityManager == null) {
			return;
		}

		if (!entityManager.getTransaction().isActive()) {
			entityManager.getTransaction().begin();
		}

		// try{
		//
		// for(Object o : oList){
		// lockEntity(o, entityManager);
		// lockedObjects.add(o);
		//
		// }
		//
		// }catch (Exception e) {
		//
		// for(Object o : lockedObjects){
		// unlockEntity(o, entityManager);
		// }
		//
		// throw e;
		//
		// }

		try {

			for (Object o : oList) {
				entityManager.persist(o);
			}

			entityManager.getTransaction().commit();
		} catch (Exception e) {

			// for(Object o : lockedObjects){
			// unlockEntity(o, entityManager);
			// }

			throw e;
		}

		// for(Object o : lockedObjects){
		// unlockEntity(o, entityManager);
		// }

	}

	public static void persistEntity(Object o, EntityManager entityManager) throws Exception {

		if (o == null || entityManager == null) {
			return;
		}

		if (!entityManager.getTransaction().isActive()) {
			entityManager.getTransaction().begin();
		}

		// try{

		entityManager.persist(o);
		entityManager.getTransaction().commit();

		// }catch (Exception e) {
		//
		// if(entityManager.getTransaction() != null &&
		// entityManager.getTransaction().isActive()){
		// try{
		// // unlockEntity(o, entityManager);
		// entityManager.getTransaction().rollback();
		// }catch (Exception exp) {
		//
		// }
		// }
		//
		// throw e;
		// }

		// unlockEntity(o, entityManager);

	}

	public static void removeEntity(Object o, EntityManager entityManager) throws Exception {

		if (o == null) {
			return;
		}

		if (!entityManager.getTransaction().isActive()) {
			entityManager.getTransaction().begin();
		}

		entityManager.remove(o);

		entityManager.getTransaction().commit();

	}
	
	public static void removeEntity(Object o) throws Exception {

		EntityManager entityManager;

		if (o == null) {
			return;
		}

		entityManager = JPAEntityManagerFactory.getEntityManagerFactory().createEntityManager();

		if (!entityManager.getTransaction().isActive()) {
			entityManager.getTransaction().begin();
		}

		entityManager.remove(o);

		entityManager.getTransaction().commit();

	}	

	// private static void lockEntity(Object o, EntityManager entityManager)
	// throws Exception{
	//
	// try{
	// entityManager.lock(o, LockModeType.PESSIMISTIC_WRITE);
	// }
	// catch (Exception e) {//Ignore exceptions raised if the entity doens't
	// exist yet
	// int i = 0;
	// i++;
	// }
	// }

	// private static void unlockEntity(Object o, EntityManager entityManager)
	// throws Exception{
	//
	// try{
	// entityManager.lock(o, LockModeType.NONE);
	// }
	// catch (Exception e) {//Ignore exceptions raised if the entity doens't
	// exist yet
	// int i = 0;
	// i++;
	// }
	// }

}
