package com.vestas.hr.vig.appConfig;

public class DomainUtils {
	
	//Domain Types
	public static final String  GAS_ERROR_TYPE = "GAS_ERROR_TYPE";
	public static final String  GAS_LOG_TYPE = "GAS_LOG_TYPE";
	public static final String  GAS_CONFIG_TYPE = "GAS_CONFIG_TYPE";
	public static final String  DOC_STATUS_TYPE = "DOC_STATUS_TYPE";
	
	//GAS_ERROR_TYPE
	public static final String  ERROR = "ERROR";
	public static final String  WARNING = "WARNING";
	public static final String  INFO = "INFO";
	public static final String  SUCCESS = "SUCCESS";
	
	//GAS_LOG_TYPE
	public static final String  TASK = "TASK";
	public static final String  ODATA = "ODATA";
	public static final String  PERFORMANCE = "PERFORMANCE";

	//GAS_CONFIG_TYPE
	public static final String  TASK_CONFIG = "TASK_CONFIG";
	public static final String  STORAGE_CONFIG = "STORAGE_CONFIG";
	public static final String  RETENTION_CONFIG = "RETENTION_CONFIG";
	public static final String  LOG_CONFIG = "LOG_CONFIG";
	
	//DOC_STATUS_TYPE
	public static final String  IN_QUEUE = "IN_QUEUE";
	public static final String  CREATED = "CREATED";
	public static final String  IN_TRASH = "IN_TRASH";
	public static final String  PENDING_DELETION_APPROVAL = "PENDING_DELETION_APPROVAL";
	public static final String  DELETED = "DELETED";
	public static final String  DOCUMENT_RESERVED = "DOCUMENT_RESERVED";
	public static final String  DEL_REQUEST_PENDING_APPROVAL = "DEL_REQUEST_PENDING_APPROVAL";
	public static final String  DEL_REQUEST_IN_TRASH = "DEL_REQUEST_IN_TRASH";
	public static final String  DEL_REQUEST_COMPLETED = "DEL_REQUEST_COMPLETED";



}
