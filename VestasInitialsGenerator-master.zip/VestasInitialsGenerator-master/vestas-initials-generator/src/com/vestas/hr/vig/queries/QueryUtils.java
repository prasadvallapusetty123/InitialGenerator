package com.vestas.hr.vig.queries;

public class QueryUtils {

}
