package com.vestas.hr.vig.appConfig;

public class AppGeneralConfigUtils {

	public static final String DATE_FORMAT = "yyyy-MM-dd hh:mm:ss";
	public static final String TASK_USER = "BATCH";
	public static final String ADMIN_USER = "ADMIN";
	public static final String CONTENT_TYPE = "CONTENT-TYPE";
	
}
