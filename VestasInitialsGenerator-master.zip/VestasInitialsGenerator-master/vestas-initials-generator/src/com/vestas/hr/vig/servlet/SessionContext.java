package com.vestas.hr.vig.servlet;

import com.sap.security.um.user.User;

public class SessionContext {

	private static final ThreadLocal<User> localRequestUser = new ThreadLocal<User>();
	private static final ThreadLocal<String> localText = new ThreadLocal<String>();
	private static final ThreadLocal<Long> localDocId = new ThreadLocal<Long>();
	private static final ThreadLocal<Boolean> localConfidential = new ThreadLocal<Boolean>();

	public static void setLocalRequestUser(User user) {
		localRequestUser.set(user);
	}
	
	public static User getLocalRequestuser() {
		return localRequestUser.get();
	}
	
	public static void setLocalText(String text) {
		localText.set(text);
	}
	
	public static String getLocalText() {
		return localText.get();
	}
	
	public static void clean() {
		localRequestUser.remove();
		localText.remove();
		localDocId.remove();
		localConfidential.remove();
	}

	public static Long getLocaldocId() {
		return localDocId.get();
	}

	public static Boolean getLocalConfidential() {
		return localConfidential.get();
	}
	
	public static void setLocaldocId(Long id) {
		localDocId.set(id);
	}

	public static void setLocalConfidential(Boolean confidential) {
		localConfidential.set(confidential);
	}
	

}
