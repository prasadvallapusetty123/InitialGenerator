package com.vestas.hr.vig.queries.initials;

public final class InitialQueryUtils {
	
	protected static final String _initialsBlackList = "SELECT b from VIGBlackList b";
	protected static final String _initialsList = "SELECT i from VIGInitials i";
	
}
