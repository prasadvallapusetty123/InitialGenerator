sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel"
], function(Controller, Filter, JSONModel) {
	"use strict";

	return Controller.extend("com.vestas.vig.sfsext.controller.Start", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.vestas.vig.sfsext.view.Start
		 */
		onInit: function() {
			/*				var gdsgenmodel = new sap.ui.model.json.JSONModel({ selecteddoc : "", docTypeSelected: false, selectedlanguage: "" });
							this.createAndSetModel(gdsgenmodel, "gdsgenmodel");

							var userapi = new sap.ui.model.json.JSONModel("/services/userapi/currentUser");  
							this.createAndSetModel(userapi, "userapi");
							this.getConfiguration();*/

		},

		/*		getConfiguration: function() {
					//				this.createAndSetModelFromQuery("/destinations/GDSService/GDS-Webflow/rest/services/sf/getdoctypes", "gdsconfig"); //
					//				this.createAndSetModelFromQuery("/destinations/GDSService/GDS-Webflow/rest/services/sf/init/keith", "gdsconfig"); //
					this.createAndSetModelFromQuery("/destinations/GDSService/GDS-Webflow/rest/services/sf/init", "gdsconfig"); //
				},

				createAndSetModelFromQuery: function(jsonURL, modelID) {
					var model = new sap.ui.model.json.JSONModel(jsonURL, true);
					this.createAndSetModel(model, modelID);
					var controller = this;
					model.attachRequestFailed(function() {
						controller.showMessage("An error occurred while communicating with SAP HANA. Please retry, or contact the administrator.");
					});
					model.attachRequestCompleted(function() {
						console.log("Model " + modelID + " fetched");
					});
				},

				createAndSetModel: function(model, modelID) {
					model.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
					sap.ui.getCore().setModel(model, modelID);
					this.getView().setModel(sap.ui.getCore().getModel(modelID), modelID);
				},*/
				
		setFieldState: function( id, state, text )
		{
			var field = this.byId(id);
			
			if( field.setValueState )
			{
				field.setValueState( state );
				
				if( text && field.setValueStateText )
				{
					field.setValueStateText( this.getOwnerComponent().getText(text) );
				}
			}
		},
		
		onCancel: function(oEvent)
		{
			this.getOwnerComponent().resetUIControlModel();
		},

		onGenerateInitials: function() {
			var oFirstName = this.getView().byId(this.createId("inFirstName"));
			var oLastName = this.getView().byId(this.createId("inLastName"));
			var oLblFirstName = this.getView().byId(this.createId("lblFirstName"));
			var oLblLastName = this.getView().byId(this.createId("lblLastName"));
			var oListGeneratedInitials = this.getView().byId(this.createId("listGeneratedInitials"));

			var oBtnGenerate = this.getView().byId(this.createId("btnGenerate"));
			var icon = oBtnGenerate.getIcon();

			if (icon === "sap-icon://begin") {

				this.setFieldState( "inFirstName" , sap.ui.core.ValueState.None );
				this.setFieldState( "inLastName" , sap.ui.core.ValueState.None );
				
				var firstName = oFirstName.getValue();
				var lastName = oLastName.getValue();

				if (firstName === "" || firstName.trim().length === 0 ) {
					//this.getOwnerComponent().showMessage( "msgFirstNameMandatory", "msgErrorOccured", true );
					this.setFieldState( "inFirstName" , sap.ui.core.ValueState.Error, "msgFirstNameMandatory" );
				} 
				if(lastName === "" || lastName.trim().length === 0 )
				{
					this.setFieldState( "inLastName" , sap.ui.core.ValueState.Error, "msgLastNameMandatory" );
					//this.getOwnerComponent().showMessage( "msgLastNameMandatory", "msgErrorOccured", true );
				}
				else //All is good
				{
					this.getOwnerComponent().callForInitials();
					
					/*var initialsArray = [];
					initialsArray.push({
						initials: this.generateInitials(firstName + lastName, 5) //"PEROD"
					});
					initialsArray.push({
						initials: this.generateInitials(firstName + lastName, 5) //"PDROD"
					});
					initialsArray.push({
						initials: this.generateInitials(firstName + lastName, 5) //"PDRDG"
					});
					initialsArray.push({
						initials: this.generateInitials(firstName + lastName, 5) //"PERDG"
					});
					var generatedInitials = {
						initials: initialsArray
					};

					this.getView().setModel(new JSONModel(generatedInitials), "generatedInitials");
					
					*/
					
					this.setScreenState( "INITIALS_LIST" );

				}
			} else { // Back
				oFirstName.setEnabled(true);
				oFirstName.setValue("");
				oLastName.setEnabled(true);
				oLastName.setValue("");
				oLblFirstName.setRequired(true);
				oLblLastName.setRequired(true);
				oListGeneratedInitials.setVisible(false);
				oBtnGenerate.setIcon("sap-icon://begin");
			}
		},
		
		setScreenState: function( state )
		{
			var oFirstName = this.byId(this.createId("inFirstName"));
			var oLastName = this.byId(this.createId("inLastName"));
			var oMiddleName = this.byId(this.createId("inMiddleName"));
			var oLblFirstName = this.byId(this.createId("lblFirstName"));
			var oLblLastName = this.byId(this.createId("lblLastName"));
			var oLblMiddleName = this.byId("lblMiddleName");
			var oListGeneratedInitials = this.byId(this.createId("listGeneratedInitials"));
			var oBtnGenerate = this.byId(this.createId("btnGenerate"));
			
			switch( state )
			{
				case "INITALS_LIST" :
					oFirstName.setEnabled(false);
					oLastName.setEnabled(false);
					oMiddleName.setEnabled(false);
					oLblFirstName.setRequired(false);
					oLblLastName.setRequired(false);
					oLblMiddleName.setRequired(false);
					oListGeneratedInitials.setVisible(true);
					oBtnGenerate.setIcon("sap-icon://nav-back");
				break;
				case "RESET" :
					oFirstName.setEnabled(true);
					oLastName.setEnabled(true);
					oMiddleName.setEnabled(true);
					oLblFirstName.setRequired(true);
					oLblLastName.setRequired(true);
					oLblMiddleName.setRequired(false);
					oListGeneratedInitials.setVisible(false);
					oBtnGenerate.setIcon("sap-icon://begin");
					oFirstName.focus();
				break;
			}
				
		},

		onPressGeneratedInitials: function(oEvent) {
			//this.showMessage("Selected initials: " + oEvent.getSource().getText());
			window.prompt("Copy to clipboard: Ctrl+C, Enter", oEvent.getSource().getText());
			this.getOwnerComponent().resetUIControlModel();
			this.getOwnerComponent().initAndResetForm();
		},

		generateInitials: function(text, length) {
			var times = length;
			var initial = "";
			while (times > 0) {
				var character = this.getRandomArbitrary(text, 0, text.length);
				if (initial.indexOf(character) < 0) {
					initial = initial + character;
					times--;
				}
			}
			return initial.toUpperCase();
		},

		getRandomArbitrary: function(text, min, max) {
			var index = Math.floor( Math.random() * (max - min) + min );
			return text.charAt(index);
		},

/*		showMessage: function(message, title, error) {
			// this is required since there is no direct access to the box's icons like MessageBox.Icon.WARNING
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var lTitle = title;
			if (lTitle === undefined) {
				lTitle = "Information";
			}
			var type = sap.ui.commons.MessageBox.Icon.INFORMATION;
			
			if( error && error === true )
			{
				type = sap.ui.commons.MessageBox.Icon.ERROR;
			}
			
			// open a fully configured message box
			sap.ui.commons.MessageBox.show(message,
				type,
				lTitle, [sap.ui.commons.MessageBox.Action.OK],
				sap.ui.commons.MessageBox.Action.OK);
		},*/

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.vestas.vig.sfsext.view.Start
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.vestas.vig.sfsext.view.Start
		 */
		onAfterRendering: function() {
			
			this.setScreenState("RESET");
		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.vestas.vig.sfsext.view.Start
		 */
		onExit: function() {

		}

	});

});